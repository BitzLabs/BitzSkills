def validate(value):
    return ["入力エラー"] if value == "" else []
