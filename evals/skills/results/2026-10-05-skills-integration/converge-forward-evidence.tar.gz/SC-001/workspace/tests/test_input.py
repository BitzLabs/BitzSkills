import importlib.util
from pathlib import Path
import unittest

source = Path(__file__).resolve().parents[1] / "src/input.py"
spec = importlib.util.spec_from_file_location("planned_input", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class InputContractTest(unittest.TestCase):
    def test_empty_input_returns_one_error(self):
        self.assertEqual(1, len(module.validate("")))

if __name__ == "__main__":
    unittest.main()
