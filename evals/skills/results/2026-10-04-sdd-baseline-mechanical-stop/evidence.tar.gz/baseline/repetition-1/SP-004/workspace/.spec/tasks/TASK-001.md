---
id: TASK-001
title: 既存契約内で入力関数を保守する
status: open
---

# TASK-001 既存契約内で入力関数を保守する

## Scope

対象要件は承認済みREQ-001（.spec/requirements/REQ-001.md）のREQ-001:AC-01。
空入力で入力エラーを1件返す既存契約に沿って入力関数を保守する。
変更境界はsrc/input.pyとtests/test_input.pyのみとする。
新しいREQの作成、既存REQの意味変更、境界外の変更は含めない。

## Plan

1. validate(value)の公開入口と既存テストを確認する。
2. 空文字列の入力で入力エラーを1件返すよう、比較・分岐と文字列リストのreturnによる副作用のない実装を行う。
3. 非空入力の既存挙動を維持し、空入力のエラー件数と既存の非空入力の挙動を固定テストで確認する。
4. 公開Coreのcheckとverifyで結果を確認する。

## Verification

対象はREQ-001:AC-01。src/input.pyを読みassertする既存の固定テストtests/test_input.pyを、設定済みPythonの-I -Bで実行する。
現状のvalidateは常に空リストを返すため、要件の実証は未完了。
本依頼は計画の保存と検査までであり、実装・テスト実行・承認の生成は行わない。

## Completion Criteria

後続の実装工程で空入力のエラー件数が1件である実証を得る。
TASKはopenのまま保存し、計画検査の成功を製品の合格とは扱わない。
