"""確定条件の原軌跡を再検査する。モデル起動や元証拠の上書きはしない。"""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-normal-01"
protocol = evaluate.load(HERE / "normal-protocol.json")
attempts = evaluate.load(output / "attempts.json")
conditions = evaluate.load(output / "conditions.json")
slots = [(c, v, r) for r in (1, 2) for v in protocol["variants"] for c in protocol["cases"]]
assert 0 < len(attempts) <= len(slots) == 8
rows, threads, controls = [], [], {}
for attempt, (case, variant, repetition) in zip(attempts, slots):
    directory = output / attempt["directory"]
    record = evaluate.load(directory / "run.json")
    identity = record["identity"]
    assert (identity["caseId"], identity["variant"], identity["repetition"]) == (case["caseId"], variant, repetition)
    assert all(identity[key] == value for key, value in conditions.items())
    errors, document = evaluate.inspect_record(directory, case, record)
    assert not any(errors.values()), errors
    assert document == evaluate.load(directory / "advice.json")
    receipt_status = "pending"
    if (directory / "independent-receipt.json").exists():
        evaluate.verify_receipt(directory)
        receipt_status = "passed"
    control = evaluate.load(directory / "control.json")
    controls[(case["caseId"], variant, repetition)] = control
    calls = evaluate.jsonl(directory / "host.jsonl")
    tests = [c for c in calls if c["tool"] == "run_fixture_test" and c["accepted"]]
    assert control["allowTests"] == (case["testExecution"] == "allowed")
    assert (not tests) if not control["allowTests"] else (tests and all(t["result"]["exitCode"] == 0 for t in tests))
    thread = [e["thread_id"] for e in evaluate.jsonl(directory / "trace.jsonl") if e.get("type") == "thread.started"]
    assert len(thread) == 1
    threads.extend(thread)
    usage = {key: sum(u.get(key, 0) for u in record["usage"]) for key in ("input_tokens", "cached_input_tokens", "output_tokens")}
    rows.append({"runId": identity["runId"], "caseId": case["caseId"], "variant": variant, "repetition": repetition,
        "sourceCommit": identity["sourceCommit"], "subjectCommit": control["subjectCommit"],
        "riskBand": document["riskBand"], "decision": document["decision"], "missingEvidenceIds": document["missingEvidenceIds"],
        "findingCount": len(document["findings"]), "humanDecisionPending": document["humanDecisionPending"],
        "independentReceipt": receipt_status, "parentErrors": errors, "testCalls": len(tests),
        "hostCalls": len(calls), "threadId": thread[0], "wallMs": record["wallMs"], "usage": usage,
        "runSha256": evaluate.sha((directory / "run.json").read_bytes()),
        "receiptSha256": evaluate.sha((directory / "independent-receipt.json").read_bytes()) if receipt_status == "passed" else None})
assert len(set(threads)) == len(attempts)
for case in protocol["cases"]:
    present = [c for (case_id, _, _), c in controls.items() if case_id == case["caseId"]]
    if not present:
        continue
    first = present[0]
    first_common = {n: h for n, h in first["readableFiles"].items() if not n.startswith("resources/bitz-quality/skills/")}
    for control in present:
        assert all(control[key] == first[key] for key in ("baseCommit", "subjectCommit", "fixtureFiles", "diff", "allowTests"))
        assert {n: h for n, h in control["readableFiles"].items() if not n.startswith("resources/bitz-quality/skills/")} == first_common
budget = evaluate.load(output / "independent-budget.json")
assert len(budget["preparation"]) == budget["maximumPreparationReviews"] == 1
assert len(budget["trajectoryReviews"]) <= budget["maximumTrajectoryReviews"] == 8
totals = {}
for variant in protocol["variants"]:
    chosen = [row for row in rows if row["variant"] == variant]
    totals[variant] = {"runs": len(chosen), "wallMs": sum(row["wallMs"] for row in chosen),
        "usage": {k: sum(row["usage"][k] for row in chosen) for k in ("input_tokens", "cached_input_tokens", "output_tokens")},
        "estimatedCostUsd": None}
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "sourceCommit": conditions["sourceCommit"],
    "primaryAttempts": len(attempts), "completedPrimaryRuns": len(rows),
    "independentPassed": sum(row["independentReceipt"] == "passed" for row in rows),
    "sameSourceAndConditions": True, "identicalCommonInputsAndPermissions": True,
    "uniqueNativeThreads": len(set(threads)), "model": conditions["model"],
    "protocolSha256": conditions["protocolSha256"], "certifiesSkillGate": False,
    "publicSyntheticCases": True, "rows": rows, "totals": totals}, ensure_ascii=False, indent=2))
