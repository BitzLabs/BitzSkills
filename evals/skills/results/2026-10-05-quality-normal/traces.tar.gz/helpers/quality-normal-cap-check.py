"""実台帳と実ソースで上限拒否を検査する。Codex呼出しは観測用spyで禁止。"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

approval_path = HERE / "normal-approval.json"
approval_hash = hashlib.sha256(approval_path.read_bytes()).hexdigest()
ledger = ROOT / ".venv" / f"quality-pilot-{approval_hash}-authorization.json"
output = ROOT / ".venv/quality-normal-01"
attempts = output / "attempts.json"
old_output = ROOT / ".venv/quality-expansion-01"
old_approval_hash = hashlib.sha256((HERE / "expansion-approval.json").read_bytes()).hexdigest()
old_ledger = ROOT / ".venv" / f"quality-pilot-{old_approval_hash}-authorization.json"
old_stop = old_output / "measurement-stop.json"
paths = (ledger, attempts, old_ledger, old_stop)
before = {str(p): p.read_bytes() for p in paths}
with tarfile.open(ROOT / "evals/skills/results/2026-10-05-quality-expansion/traces.tar.gz", "r:gz") as original:
    names = {str(PurePosixPath(m.name)): m for m in original.getmembers()}
    assert before[str(old_ledger)] == original.extractfile(names["authorization-ledger.json"]).read()
    assert before[str(old_stop)] == original.extractfile(names["measurement-stop.json"]).read()
assert json.loads(before[str(ledger)])["attemptCount"] == 8
assert len(json.loads(before[str(attempts)])) == 8
native_run = subprocess.run
codex_calls = []

def guarded_run(argv, *args, **kwargs):
    if Path(argv[0]).name == "codex":
        codex_calls.append(argv)
        raise AssertionError("上限後のCodex起動は禁止")
    return native_run(argv, *args, **kwargs)

try:
    with patch.object(evaluate.subprocess, "run", side_effect=guarded_run):
        evaluate.measure(SimpleNamespace(output=output, protocol=HERE / "normal-protocol.json",
            approval=approval_path, timeout=600))
except ValueError as error:
    reason = str(error)
    assert reason == "global authorized trajectory budget exhausted", reason
else:
    raise AssertionError("上限拒否が必要")
assert not codex_calls
assert all(p.read_bytes() == before[str(p)] for p in paths)
resume = json.loads((old_output / "independent-review-resume-01.json").read_text())
assert any(a["status"] == "usage_limit" for a in resume["previousIndependentCalls"])
print(json.dumps({"status": "passed", "reason": reason, "codexCalls": 0,
    "ledgerUnchanged": True, "attemptsUnchanged": True, "oldExpansionLedgerUnchanged": True,
    "oldUsageLimitStopUnchanged": True, "originalIndependentInterruptionPreserved": True,
    "oldExpansionLedgerAndStopMatchCommittedArchive": True,
    "sourceCommit": evaluate.preflight.git(["rev-parse", "HEAD"], ROOT, evaluate.preflight.environment()).decode().strip()}, ensure_ascii=False))
