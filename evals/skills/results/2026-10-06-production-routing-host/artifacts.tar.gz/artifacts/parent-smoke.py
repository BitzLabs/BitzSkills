import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/hide/BitzLabs/BitzSkills/.venv/skills-integration-worktree')
DIRECTORY = ROOT / '.venv/production-routing-host-01'
SNAPSHOT = ROOT / '.venv/production-routing-preparation-01/snapshot'
raw = (SNAPSHOT / 'manifest.json').read_bytes()
manifest = json.loads(raw)
pin = hashlib.sha256(raw).hexdigest()
assert pin == '603333c4bbe52047b54003183830d989ada91f35bb810f78e7f59a2dd575482b'
before = {name: hashlib.sha256((SNAPSHOT / name).read_bytes()).hexdigest() for name in manifest['resources']}
assert before == manifest['resources']
chosen = [s['path'] for s in manifest['skills'] if s['name'] in {'bitz-core', 'sdd-plan', 'quality-review'}]
requests = [
    {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2024-11-05'}},
    {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
    {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'list_resources', 'arguments': {}}},
]
for index, name in enumerate(chosen, 4):
    requests.append({'jsonrpc': '2.0', 'id': index, 'method': 'tools/call', 'params': {'name': 'read_resource', 'arguments': {'path': name}}})
requests.append({'jsonrpc': '2.0', 'id': 7, 'method': 'tools/call', 'params': {'name': 'run_bitz', 'arguments': {'operation': 'check'}}})
requests.append({'jsonrpc': '2.0', 'id': 8, 'method': 'tools/call', 'params': {'name': 'read_resource', 'arguments': {'path': 'cases.json'}}})
command = [sys.executable, '-B', str(ROOT / 'evals/skills/routing/host.py'), '--snapshot', str(SNAPSHOT),
           '--manifest-sha256', pin, '--log', str(DIRECTORY / 'parent-host.jsonl')]
result = subprocess.run(command, input='\n'.join(json.dumps(r) for r in requests) + '\n', text=True, capture_output=True, timeout=30)
assert result.returncode == 0 and result.stderr == ''
responses = [json.loads(line) for line in result.stdout.splitlines()]
assert [r['id'] for r in responses] == list(range(1, 9))
assert {t['name'] for t in responses[1]['result']['tools']} == {'list_resources', 'read_resource'}
listing = json.loads(responses[2]['result']['content'][0]['text'])
assert listing['manifestSha256'] == pin
assert len(listing['skills']) == 6 and set(listing['resources']) == set(before)
for response, name in zip(responses[3:6], chosen):
    observed = json.loads(response['result']['content'][0]['text'])
    assert observed['path'] == name
    assert hashlib.sha256(observed['content'].encode()).hexdigest() == before[name] == observed['sha256']
assert all(r['result']['isError'] for r in responses[6:])
calls = [json.loads(line) for line in (DIRECTORY / 'parent-host.jsonl').read_text().splitlines()]
assert len(calls) == 6 and sum(c['accepted'] for c in calls) == 4
assert (DIRECTORY / 'parent-host.jsonl').stat().st_mode & 0o777 == 0o600
assert before == {name: hashlib.sha256((SNAPSHOT / name).read_bytes()).hexdigest() for name in before}
summary = {'status': 'passed', 'nativeExitCode': result.returncode, 'modelTrajectories': 0, 'manifestSha256': pin,
           'resourcesUnchanged': len(before), 'skillCount': 6, 'hostCalls': len(calls), 'accepted': 4, 'rejected': 2,
           'tools': ['list_resources', 'read_resource'], 'sourceCommit': manifest['sourceCommit'], 'certifiesSkillGate': False}
with (DIRECTORY / 'parent-smoke.json').open('x') as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
print(json.dumps(summary, ensure_ascii=False))
