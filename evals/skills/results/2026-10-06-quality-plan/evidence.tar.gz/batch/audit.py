"""Reinspect actual fixed-run evidence; never invoke a model."""
import argparse
import hashlib
import json
import pathlib
import sys

repo = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / "evals/skills/quality"))
import evaluate

parser = argparse.ArgumentParser()
parser.add_argument("directory", type=pathlib.Path)
parser.add_argument("--pending", action="store_true")
args = parser.parse_args()
directory = args.directory.resolve()
record = evaluate.load(directory / "run.json")
case = evaluate.load(evaluate.HERE / "plan-protocol.json")["cases"][0]
assert record["identity"]["sourceCommit"] == "cbd6700fb6f205f50eafe3dcd4b155da2b3508df"
assert record["identity"]["evaluationSetVersion"] == "quality-plan-comparison-0.1.0"
assert record["identity"]["caseId"] == case["caseId"]
assert record["identity"]["model"] == "gpt-6.1-sol"
assert record["identity"]["executionVersion"] == "quality-execution-0.1.5"
errors, document = evaluate.inspect_record(directory, case, record)
assert not any(errors.values()), errors
assert record["checks"] == errors
assert document == evaluate.load(directory / "advice.json")
assert document["kind"] == "quality-plan"
calls = evaluate.jsonl(directory / "host.jsonl")
assert not any(c["tool"] == "run_fixture_test" for c in calls)
assert evaluate.load(directory / "control.json")["allowTests"] is False
assert document["advisory"] is True and document["humanDecisionPending"] is True
if not args.pending:
    assert evaluate.verify_receipt(directory) == record
print(json.dumps({"status": "passed", "receiptRequired": not args.pending,
                  "runId": record["identity"]["runId"],
                  "runSha256": hashlib.sha256((directory / "run.json").read_bytes()).hexdigest(),
                  "checks": errors, "testCalls": 0,
                  "riskBand": document["risk"]["band"],
                  "planningStatus": document["planningStatus"],
                  "hostCalls": len(calls),
                  "usage": record.get("usage"),
                  "wallMs": record["wallMs"],
                  "certifiesSkillGate": False}, indent=2))
