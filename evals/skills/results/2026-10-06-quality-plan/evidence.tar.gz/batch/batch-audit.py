"""Audit finite completed comparison from actual receipts and source artifacts."""
import hashlib
import json
import pathlib
import sys

repo = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / "evals/skills/quality"))
import evaluate

output = pathlib.Path(__file__).resolve().parent
attempts = evaluate.load(output / "attempts.json")
assert len(attempts) == 4
case = evaluate.load(evaluate.HERE / "plan-protocol.json")["cases"][0]
conditions = evaluate.load(output / "conditions.json")
assert {(a["identity"]["variant"], a["identity"]["repetition"]) for a in attempts} == {
    ("skill", 1), ("baseline", 1), ("skill", 2), ("baseline", 2)}
assert conditions["pluginFiles"] == evaluate.preflight.files(evaluate.PACKAGE)
threads, receipts, fixtures, common, refs, summaries = [], [], [], [], [], []
for attempt in attempts:
    directory = output / attempt["directory"]
    record = evaluate.verify_receipt(directory)
    assert record["identity"] == attempt["identity"]
    for key, value in conditions.items():
        assert record["identity"][key] == value
    assert record["identity"]["sourceCommit"] == "cbd6700fb6f205f50eafe3dcd4b155da2b3508df"
    errors, document = evaluate.inspect_record(directory, case, record)
    assert not any(errors.values()) and record["checks"] == errors
    assert document == evaluate.load(directory / "advice.json")
    assert document["advisory"] and document["humanDecisionPending"]
    control = evaluate.load(directory / "control.json")
    assert control["allowTests"] is False
    assert not any(c["tool"] == "run_fixture_test" for c in evaluate.jsonl(directory / "host.jsonl"))
    fixtures.append(control["fixtureFiles"])
    common.append({p: h for p, h in control["readableFiles"].items()
                   if not p.startswith("resources/bitz-quality/skills/")})
    refs.append((control["baseCommit"], control["subjectCommit"], control["diff"]))
    trace = evaluate.jsonl(directory / "trace.jsonl")
    ids = [e["thread_id"] for e in trace if e["type"] == "thread.started"]
    assert len(ids) == 1
    threads.extend(ids)
    receipt = evaluate.load(directory / "independent-receipt.json")
    receipts.append(receipt["reviewRunId"])
    summaries.append({"runId": record["identity"]["runId"],
                      "variant": record["identity"]["variant"],
                      "repetition": record["identity"]["repetition"],
                      "wallMs": record["wallMs"], "usage": record["usage"],
                      "riskBand": document["risk"]["band"],
                      "planningStatus": document["planningStatus"],
                      "runSha256": hashlib.sha256((directory / "run.json").read_bytes()).hexdigest()})
assert len(set(threads)) == len(set(receipts)) == 4
assert all(v == fixtures[0] for v in fixtures)
assert all(v == common[0] for v in common)
assert all(v == refs[0] for v in refs)
assert refs[0][0] == refs[0][1] and refs[0][2] == ""
print(json.dumps({"status": "passed", "sourceCommit": conditions["sourceCommit"],
                  "primaryTrajectories": 4, "independentReceipts": 4,
                  "uniqueThreads": 4, "sharedInputsMatched": True,
                  "sameTestPermission": True, "testCalls": 0,
                  "runs": summaries, "estimatedCostUsd": None,
                  "certifiesSkillGate": False}, ensure_ascii=False, indent=2))
