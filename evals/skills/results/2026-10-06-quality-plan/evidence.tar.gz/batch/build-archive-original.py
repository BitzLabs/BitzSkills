import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

repo = pathlib.Path(__file__).resolve().parents[2]
run_root = pathlib.Path(__file__).resolve().parent
prep = repo / ".venv/quality-plan-preparation-01"
out = repo / "evals/skills/results/2026-10-06-quality-plan"
source = "cbd6700fb6f205f50eafe3dcd4b155da2b3508df"
sha = lambda b: hashlib.sha256(b).hexdigest()
audit = json.loads((run_root / "batch-audit.json").read_text())
assert audit["status"] == "passed" and audit["primaryTrajectories"] == 4
entries = {}
for path in prep.iterdir():
    if path.is_file():
        entries["preparation/" + path.name] = path.read_bytes()
for path in run_root.iterdir():
    if path.is_file():
        entries["batch/" + path.name] = path.read_bytes()
for attempt in json.loads((run_root / "attempts.json").read_text()):
    directory = run_root / attempt["directory"]
    record = json.loads((directory / "run.json").read_text())
    for name, expected in record["artifacts"].items():
        assert sha((directory / name).read_bytes()) == expected
    # Provider stderr is locally retained and hashed, not exported as raw text.
    for name in ["run.json", "control.json", "model-config.json", "prompt.txt",
                 "host.jsonl", "trace.jsonl", "response.json", "advice.json",
                 "workspace-before.json", "independent-receipt.json", "independent-checks.txt"]:
        entries["runs/" + directory.name + "/" + name] = (directory / name).read_bytes()
    control = json.loads((directory / "control.json").read_text())
    workspace = directory / "QP-001"
    for name, expected in control["readableFiles"].items():
        content = (workspace / name).read_bytes()
        assert sha(content) == expected
        entries["runs/" + directory.name + "/workspace/" + name] = content
approval_path = repo / "evals/skills/quality/plan-approval.json"
approval_hash = sha(approval_path.read_bytes())
ledger = repo / ".venv" / ("quality-pilot-" + approval_hash + "-authorization.json")
entries["batch/authorization-ledger.json"] = ledger.read_bytes()
assert json.loads(ledger.read_bytes())["attemptCount"] == 4
source_paths = set(subprocess.check_output(
    ["git", "ls-tree", "-r", "--name-only", source, "--",
     "plugins/bitz-quality", "evals/skills/quality/fixtures/plan"],
    cwd=repo, text=True).splitlines())
source_paths.update("evals/skills/quality/" + name for name in [
    "evaluate.py", "host.py", "preflight.py", "response.schema.json", "receipt.schema.json",
    "advice-format.md", "core-cli.md", "plan-protocol.json", "plan-approval.json", "protocol.json"])
source_paths.update(["evals/skills/sol-authorization.json", "evals/skills/core-compat.json",
                     "tests/skills/test_quality_evaluation.py", "tests/skills/test_quality_interruption.py"])
fixed = []
for path in sorted(source_paths):
    content = subprocess.check_output(["git", "show", source + ":" + path], cwd=repo)
    assert content == (repo / path).read_bytes()
    name = "source/" + path
    entries[name] = content
    fixed.append({"ref": source, "path": path, "archivePath": name})
out.mkdir()
with tarfile.open(out / "evidence.tar.gz", "w:gz") as bundle:
    for name, content in sorted(entries.items()):
        item = tarfile.TarInfo(name)
        item.size, item.mtime = len(content), 0
        bundle.addfile(item, io.BytesIO(content))
manifest = {"schemaVersion": "1.0", "archiveSha256": sha((out / "evidence.tar.gz").read_bytes()),
            "files": {name: {"bytes": len(content), "sha256": sha(content)}
                      for name, content in sorted(entries.items())},
            "fixedSources": fixed,
            "providerStderr": "raw omitted; native files locally preserved and hash verified"}
(out / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"files": len(entries), "fixedSources": len(fixed),
                  "bytes": sum(map(len, entries.values())), "archiveSha256": manifest["archiveSha256"]}))
