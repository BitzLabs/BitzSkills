"""Probe refusal with a backend spy; no paid trajectory or retry."""
import argparse
import hashlib
import json
import pathlib
import sys
from types import SimpleNamespace
from unittest.mock import patch

repo = pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo / "evals/skills/quality"))
import evaluate

parser = argparse.ArgumentParser()
parser.add_argument("--cap", action="store_true")
args = parser.parse_args()
output = pathlib.Path(__file__).resolve().parent
approval = evaluate.HERE / "plan-approval.json"
ledger = evaluate.authorization_directory() / (
    "quality-pilot-" + hashlib.sha256(approval.read_bytes()).hexdigest() + "-authorization.json")
paths = [output / "attempts.json", ledger]
before = {str(p): p.read_bytes() for p in paths}
expected = ("global authorized trajectory budget exhausted" if args.cap else
            "previous trajectory needs independent review; no new call")
real_run = evaluate.subprocess.run
backend_calls = []
def backend(command, **kwargs):
    if command[0] == "codex":
        backend_calls.append(command)
        raise AssertionError("paid backend must not be called by this probe")
    return real_run(command, **kwargs)
with patch("evaluate.subprocess.run", side_effect=backend):
    try:
        evaluate.measure(SimpleNamespace(output=output, timeout=600,
            protocol=evaluate.HERE / "plan-protocol.json", approval=approval))
    except ValueError as error:
        assert str(error) == expected, (str(error), expected)
    else:
        raise AssertionError("refusal was expected")
    assert not backend_calls
assert before == {str(p): p.read_bytes() for p in paths}
print(json.dumps({"status": "passed", "refusal": expected, "backendCalls": 0,
                  "attemptAndLedgerBytesUnchanged": True, "automaticRetry": False}))
