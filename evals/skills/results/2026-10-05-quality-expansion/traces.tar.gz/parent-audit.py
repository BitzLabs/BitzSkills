"""確定した原8軌跡を再検査し、公開比較の事実だけを集計する。"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-expansion-01"
protocol = evaluate.load(HERE / "expansion-protocol.json")
attempts = evaluate.load(output / "attempts.json")
conditions = evaluate.load(output / "conditions.json")
slots = [(c, v, r) for r in range(1, 3) for v in protocol["variants"] for c in protocol["cases"]]
assert len(attempts) == len(slots) == 8
rows = []
controls = {}
threads = []
for attempt, (case, variant, repetition) in zip(attempts, slots):
    directory = output / attempt["directory"]
    record = evaluate.verify_receipt(directory)
    identity = record["identity"]
    assert (identity["caseId"], identity["variant"], identity["repetition"]) == (case["caseId"], variant, repetition)
    assert all(identity[key] == value for key, value in conditions.items())
    assert identity["executionVersion"] == "quality-execution-0.1.2"
    errors, document = evaluate.inspect_record(directory, case, record)
    assert not any(errors.values()), errors
    assert document == evaluate.load(directory / "advice.json")
    receipt = evaluate.load(directory / "independent-receipt.json")
    assert all(value == "passed" for value in receipt["checks"].values())
    control = evaluate.load(directory / "control.json")
    controls[(case["caseId"], variant, repetition)] = control
    calls = evaluate.jsonl(directory / "host.jsonl")
    tests = [c for c in calls if c["tool"] == "run_fixture_test" and c["accepted"]]
    if case["testExecution"] == "not_authorized":
        assert not tests and not control["allowTests"]
    else:
        assert tests and control["allowTests"] and all(t["result"]["exitCode"] == 0 for t in tests)
    thread = [e["thread_id"] for e in evaluate.jsonl(directory / "trace.jsonl") if e.get("type") == "thread.started"]
    assert len(thread) == 1
    threads.extend(thread)
    usage = {key: sum(u.get(key, 0) for u in record["usage"]) for key in ("input_tokens", "cached_input_tokens", "output_tokens")}
    rows.append({"runId": identity["runId"], "caseId": case["caseId"], "variant": variant,
        "repetition": repetition, "sourceCommit": identity["sourceCommit"], "subjectCommit": control["subjectCommit"],
        "decision": document["decision"], "riskBand": document["riskBand"], "missingEvidenceIds": document["missingEvidenceIds"],
        "checks": receipt["checks"], "parentErrors": errors, "testCalls": len(tests), "hostCalls": len(calls),
        "threadId": thread[0], "wallMs": record["wallMs"], "usage": usage,
        "runSha256": hashlib.sha256((directory / "run.json").read_bytes()).hexdigest(),
        "receiptSha256": hashlib.sha256((directory / "independent-receipt.json").read_bytes()).hexdigest()})
assert len(set(threads)) == 8
for case in protocol["cases"]:
    baseline = controls[(case["caseId"], "baseline", 1)]
    for variant in protocol["variants"]:
        for repetition in (1, 2):
            control = controls[(case["caseId"], variant, repetition)]
            assert all(control[key] == baseline[key] for key in ("baseCommit", "subjectCommit", "fixtureFiles", "diff", "allowTests"))
            common = {name: value for name, value in control["readableFiles"].items()
                      if not name.startswith("resources/bitz-quality/skills/")}
            assert common == baseline["readableFiles"]
resume = evaluate.load(output / "independent-review-resume-01.json")
assert len(resume["attempts"]) == resume["maximumNewIndependentCalls"] == 7
assert all(a["status"] == "passed" for a in resume["attempts"])
assert any(a["status"] == "usage_limit" for a in resume["previousIndependentCalls"])
totals = {}
for variant in protocol["variants"]:
    selected = [row for row in rows if row["variant"] == variant]
    totals[variant] = {"runs": len(selected), "wallMs": sum(row["wallMs"] for row in selected),
        "usage": {key: sum(row["usage"][key] for row in selected) for key in selected[0]["usage"]}, "estimatedCostUsd": None}
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "sourceCommit": conditions["sourceCommit"],
    "primaryAttempts": 8, "completedPrimaryRuns": 8, "independentPassed": 8,
    "independentUsageLimitInterruptions": 1, "sameSourceAndConditions": True, "identicalCommonInputsAndPermissions": True,
    "uniqueNativeThreads": 8, "certifiesSkillGate": False, "publicSyntheticCases": True,
    "model": conditions["model"], "protocolSha256": conditions["protocolSha256"], "rows": rows, "totals": totals}, ensure_ascii=False, indent=2))
