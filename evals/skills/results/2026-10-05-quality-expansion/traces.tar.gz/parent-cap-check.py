"""原台帳と実ソースを使い、上限後のCodex起動0を直接検査する。"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

approval_path = HERE / "expansion-approval.json"
approval_sha = hashlib.sha256(approval_path.read_bytes()).hexdigest()
ledger = ROOT / ".venv" / f"quality-pilot-{approval_sha}-authorization.json"
output = ROOT / ".venv/quality-expansion-01"
attempts = output / "attempts.json"
before = {str(p): p.read_bytes() for p in (ledger, attempts)}
assert json.loads(before[str(ledger)])["attemptCount"] == 8
assert len(json.loads(before[str(attempts)])) == 8
native_run = subprocess.run
codex_calls = []

def guarded_run(argv, *args, **kwargs):
    if Path(argv[0]).name == "codex":
        codex_calls.append(argv)
        raise AssertionError("上限後にCodexを起動してはいけない")
    return native_run(argv, *args, **kwargs)

try:
    with patch.object(evaluate.subprocess, "run", side_effect=guarded_run):
        evaluate.measure(SimpleNamespace(output=output, protocol=HERE / "expansion-protocol.json",
            approval=approval_path, timeout=600))
except ValueError as error:
    reason = str(error)
    assert reason == "global authorized trajectory budget exhausted", reason
else:
    raise AssertionError("上限拒否が必要")
assert not codex_calls
assert all(p.read_bytes() == before[str(p)] for p in (ledger, attempts))
resume = json.loads((output / "independent-review-resume-01.json").read_text())
assert any(a["status"] == "usage_limit" for a in resume["previousIndependentCalls"])
print(json.dumps({"status": "passed", "reason": reason, "codexCalls": 0,
    "ledgerUnchanged": True, "attemptsUnchanged": True, "originalIndependentInterruptionPreserved": True,
    "sourceCommit": evaluate.preflight.git(["rev-parse", "HEAD"], ROOT, evaluate.preflight.environment()).decode().strip()}, ensure_ascii=False))
