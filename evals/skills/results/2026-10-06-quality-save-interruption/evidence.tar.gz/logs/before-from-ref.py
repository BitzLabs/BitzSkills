"""Execute new regression tests against exact original evaluator bytes."""
import pathlib
import subprocess
import sys
import types
import unittest

repo = pathlib.Path(__file__).resolve().parents[2]
source = repo / "evals/skills/quality/evaluate.py"
tests = repo / "tests/skills/test_quality_interruption.py"
sys.path.insert(0, str(source.parent))
old = subprocess.check_output(["git", "show", "3e181af4:evals/skills/quality/evaluate.py"], cwd=repo)
assert tests.read_bytes() == subprocess.check_output(
    ["git", "show", "07db2a7:tests/skills/test_quality_interruption.py"], cwd=repo)
module = types.ModuleType("evaluate")
module.__file__ = str(source)
sys.modules["evaluate"] = module
exec(compile(old, str(source), "exec"), module.__dict__)
suite_module = types.ModuleType("fixed_ref_tests")
suite_module.__file__ = str(tests)
exec(compile(tests.read_bytes(), str(tests), "exec"), suite_module.__dict__)
result = unittest.TextTestRunner(verbosity=1).run(
    unittest.defaultTestLoader.loadTestsFromModule(suite_module))
sys.exit(0 if result.wasSuccessful() else 1)
