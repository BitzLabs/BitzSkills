import pathlib,json,hashlib,subprocess,tarfile,io
r=pathlib.Path(__file__).resolve().parents[2]
s=r/".venv/quality-save-interruption-01"
o=r/"evals/skills/results/2026-10-06-quality-save-interruption"
v=json.loads((s/"review.json").read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert v["status"]=="passed" and not v["findings"]
for path,h in v["hash"].items():
 assert h==sha((r/path).read_bytes())
 assert (r/path).read_bytes()==subprocess.check_output(["git","show",v["sourceCommit"]+":"+path],cwd=r)
assert v["tests"]["independent"]["logSha256"]==sha((s/"independent-tests.txt").read_bytes())
assert "Ran 89 tests" in (s/"parent-recheck-tests.txt").read_text()
assert (s/"parent-recheck-tests.txt").read_text().strip().endswith("OK")
entries={}
for name in ["scope.json","review.json","independent-tests.txt","original-tests.txt","original-fixed-ref-tests.txt","before-from-ref.py","corrected-tests.txt","quality-tests.txt","all-skills.txt","parent-recheck-tests.txt","build-archive.py"]:
 entries["logs/"+name]=(s/name).read_bytes()
scope=json.loads(entries["logs/scope.json"])
entries["logs/budget-final.json"]=json.dumps({**scope,"status":"completed","consumedIndependentReviewCalls":1,"remainingIndependentReviewCalls":0,"consumedPrimaryTrajectories":0},indent=2,ensure_ascii=False).encode()
entries["logs/parent-audit.json"]=json.dumps({"status":"passed","sourceHashMatched":True,"independentLogHashMatched":True,"parentRecheckExitCode":0,"allUnitExitCode":0,"originalFixedRefExitCode":1,"certifiesSkillGate":False},indent=2).encode()
fixed=[]
for ref,label in [("3e181af4","before"),(v["sourceCommit"],"after")]:
 for path in v["hash"]:
  name="source/"+label+"/"+path
  entries[name]=subprocess.check_output(["git","show",ref+":"+path],cwd=r)
  fixed.append({"ref":ref,"path":path,"archivePath":name})
with tarfile.open(o/"evidence.tar.gz","w:gz") as t:
 for name,b in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0
  t.addfile(info,io.BytesIO(b))
m={"schemaVersion":"1.0","archiveSha256":sha((o/"evidence.tar.gz").read_bytes()),"files":{n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(entries.items())},"fixedSources":fixed}
(o/"manifest.json").write_text(json.dumps(m,indent=2)+"\n")
print("archive prepared",len(entries))
