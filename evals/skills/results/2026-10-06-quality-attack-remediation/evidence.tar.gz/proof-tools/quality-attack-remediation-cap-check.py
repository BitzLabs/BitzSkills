"""4枠消費後の追加backend 0と旧台帳・中断保持を実検査する。"""
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-attack-remediation-01"
approval = HERE / "attack-remediation-approval.json"
ledger = ROOT / ".venv" / ("quality-pilot-" + evaluate.sha(approval.read_bytes()) + "-authorization.json")
paths = [ledger, output / "attempts.json", output / "independent-budget.json"]
before = {str(p): p.read_bytes() for p in paths}
old = evaluate.load(ROOT / ".venv/quality-attack-remediation-preparation-01/parent-audit.json")["oldEvidence"]
assert all(evaluate.sha((ROOT / p).read_bytes()) == h for p, h in old.items())
assert evaluate.load(ledger)["attemptCount"] == len(evaluate.load(output / "attempts.json")) == 4
backend_calls = []
original_run = evaluate.subprocess.run


def forbidden(*args, **kwargs):
    if args[0][0] == "codex":
        backend_calls.append(args)
        raise AssertionError("budget exhausted; backend must not execute")
    return original_run(*args, **kwargs)


reason = None
with patch("evaluate.subprocess.run", side_effect=forbidden):
    try:
        evaluate.measure(SimpleNamespace(output=output, protocol=HERE / "attack-remediation-protocol.json", approval=approval, timeout=600))
    except ValueError as error:
        reason = str(error)
assert reason == "global authorized trajectory budget exhausted", reason
assert not backend_calls
assert before == {str(p): p.read_bytes() for p in paths}
assert all(evaluate.sha((ROOT / p).read_bytes()) == h for p, h in old.items())
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "primaryAttempts": 4,
    "additionalBackendCalls": len(backend_calls), "ledgerAndAttemptsUnchanged": True,
    "oldEvidenceUnchanged": len(old), "reason": reason, "automaticRetry": False}, ensure_ascii=False, indent=2))
