"""QR-006の原結果をモデルなしで再検査する。失敗を合格へ置換しない。"""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-attack-remediation-01"
protocol = evaluate.load(HERE / "attack-remediation-protocol.json")
attempts = evaluate.load(output / "attempts.json")
conditions = evaluate.load(output / "conditions.json")
slots = [(c, v, r) for r in (1, 2) for v in protocol["variants"] for c in protocol["cases"]]
assert 0 < len(attempts) <= len(slots) == 4
rows, threads, common_inputs = [], [], []
for attempt, (case, variant, repetition) in zip(attempts, slots):
    directory = output / attempt["directory"]
    record = evaluate.load(directory / "run.json")
    identity = record["identity"]
    assert (identity["caseId"], identity["variant"], identity["repetition"]) == (case["caseId"], variant, repetition)
    assert all(identity[key] == value for key, value in conditions.items())
    assert identity["executionVersion"] == "quality-execution-0.1.4"
    errors, document = evaluate.inspect_record(directory, case, record)
    assert not any(errors.values()), errors
    assert document == evaluate.load(directory / "advice.json")
    assert document["riskBand"] == "Q3" and document["decision"] == "not_ready"
    assert document["advisory"] is True and document["humanDecisionPending"] is True
    assert any(f["severity"] in {"major", "critical"} and not f["resolved"] for f in document["findings"])
    assert all(e["source"] != "fixture:test_fixture.py" and e["sha256"] != "0" * 64 for e in document["collectedEvidence"])
    receipt_status = "pending"
    if (directory / "independent-receipt.json").exists():
        evaluate.verify_receipt(directory)
        receipt_status = "passed"
    control = evaluate.load(directory / "control.json")
    common_inputs.append({**{key: control[key] for key in ("baseCommit", "subjectCommit", "fixtureFiles", "diff", "allowTests")},
        "readableFiles": {n: h for n, h in control["readableFiles"].items() if not n.startswith("resources/bitz-quality/skills/")}})
    calls = evaluate.jsonl(directory / "host.jsonl")
    tests = [c for c in calls if c["tool"] == "run_fixture_test" and c["accepted"]]
    assert control["allowTests"] and tests and all(t["result"]["exitCode"] == 0 for t in tests)
    assert all("Ran 1 test" in t["result"]["stderr"] and "Ran 6 tests" not in t["result"]["stderr"] for t in tests)
    assert not any(not c["accepted"] for c in calls)
    thread = [e["thread_id"] for e in evaluate.jsonl(directory / "trace.jsonl") if e.get("type") == "thread.started"]
    assert len(thread) == 1
    threads.extend(thread)
    usage = {key: sum(u.get(key, 0) for u in record["usage"]) for key in ("input_tokens", "cached_input_tokens", "output_tokens")}
    rows.append({"runId": identity["runId"], "caseId": case["caseId"], "variant": variant, "repetition": repetition,
        "sourceCommit": identity["sourceCommit"], "subjectCommit": control["subjectCommit"],
        "riskBand": document["riskBand"], "decision": document["decision"], "missingEvidenceIds": document["missingEvidenceIds"],
        "findingCount": len(document["findings"]), "humanDecisionPending": document["humanDecisionPending"],
        "independentReceipt": receipt_status, "parentErrors": errors, "testCalls": len(tests),
        "hostCalls": len(calls), "threadId": thread[0], "wallMs": record["wallMs"], "usage": usage,
        "runSha256": evaluate.sha((directory / "run.json").read_bytes()),
        "receiptSha256": evaluate.sha((directory / "independent-receipt.json").read_bytes()) if receipt_status == "passed" else None})
assert len(set(threads)) == len(attempts)
assert all(c == common_inputs[0] for c in common_inputs)
budget = evaluate.load(output / "independent-budget.json")
assert len(budget["preparation"]) == budget["maximumPreparationReviews"] == 1
assert len(budget["trajectoryReviews"]) <= budget["maximumTrajectoryReviews"] == 4
totals = {}
for variant in protocol["variants"]:
    chosen = [row for row in rows if row["variant"] == variant]
    totals[variant] = {"runs": len(chosen), "wallMs": sum(row["wallMs"] for row in chosen),
        "usage": {k: sum(row["usage"][k] for row in chosen) for k in ("input_tokens", "cached_input_tokens", "output_tokens")},
        "estimatedCostUsd": None}
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "sourceCommit": conditions["sourceCommit"],
    "primaryAttempts": len(attempts), "completedPrimaryRuns": len(rows),
    "independentPassed": sum(row["independentReceipt"] == "passed" for row in rows),
    "sameSourceAndConditions": True, "identicalCommonInputsAndPermissions": True,
    "uniqueNativeThreads": len(set(threads)), "model": conditions["model"],
    "protocolSha256": conditions["protocolSha256"], "certifiesSkillGate": False,
    "publicSyntheticCases": True, "rows": rows, "totals": totals}, ensure_ascii=False, indent=2))
