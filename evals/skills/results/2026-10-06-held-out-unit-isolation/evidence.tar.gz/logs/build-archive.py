import pathlib,json,hashlib,subprocess,tarfile,io
r=pathlib.Path(__file__).resolve().parents[2]
s=r/".venv/held-out-unit-isolation-01"
o=r/"evals/skills/results/2026-10-06-held-out-unit-isolation"
v=json.loads((s/"review.json").read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert v["sourceHash"]==sha((r/"tests/skills/test_skill_eval.py").read_bytes())
assert v["logHash"]==sha((s/"independent-tests.txt").read_bytes())
assert v["status"]=="passed-with-limits" and not v["findings"]
assert "Ran 196 tests in 53.229s" in (s/"all-skills.txt").read_text()
assert "Ran 29 tests in 5.957s" in (s/"parent-recheck-tests.txt").read_text()
entries={}
for name in ["scope.json","review.json","independent-tests.txt","after-tests.txt","all-skills.txt","parent-recheck-tests.txt","before-fixed-ref-tests.txt","before-from-ref.py","build-archive.py"]:
 entries["logs/"+name]=(s/name).read_bytes()
scope=json.loads(entries["logs/scope.json"])
entries["logs/budget-final.json"]=json.dumps({**scope,"status":"completed","consumedIndependentReviewCalls":1,"remainingIndependentReviewCalls":0,"consumedPrimaryTrajectories":0},indent=2,ensure_ascii=False).encode()
fixed=[]
for ref,label in [("d31900c6","before"),("edaf5a0660d5952d65d6f20c08fb47030af291f0","after")]:
 for path in ["tests/skills/test_skill_eval.py","evals/skills/validate.py","evals/skills/run_model.py"]:
  name="source/"+label+"/"+path
  entries[name]=subprocess.check_output(["git","show",ref+":"+path],cwd=r)
  fixed.append({"ref":ref,"path":path,"archivePath":name})
for path in ["evals/skills/validate.py","evals/skills/run_model.py"]:
 assert entries["source/before/"+path]==entries["source/after/"+path]
entries["logs/parent-audit.json"]=json.dumps({"status":"passed","sourceHashMatched":True,"independentLogHashMatched":True,"productionFilesUnchanged":True,"parentRecheckExitCode":0,"allUnitExitCode":0,"originalFixedRefExitCode":1,"certifiesSkillGate":False},indent=2).encode()
with tarfile.open(o/"evidence.tar.gz","w:gz") as t:
 for name,b in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0
  t.addfile(info,io.BytesIO(b))
m={"schemaVersion":"1.0","archiveSha256":sha((o/"evidence.tar.gz").read_bytes()),"files":{n:{"bytes":len(b),"sha256":sha(b)} for n,b in sorted(entries.items())},"fixedSources":fixed}
(o/"manifest.json").write_text(json.dumps(m,indent=2)+"\n")
print("archive prepared",len(entries))
