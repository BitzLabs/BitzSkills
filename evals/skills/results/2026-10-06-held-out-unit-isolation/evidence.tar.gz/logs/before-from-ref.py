"""確定refの単体試験本文を実repo内TMPDIRで再現する。"""
import subprocess
from pathlib import Path
import types
import unittest

ROOT = Path(__file__).resolve().parents[2]
ref = "d31900c6"
source = subprocess.check_output(["git", "show", ref + ":tests/skills/test_skill_eval.py"], cwd=ROOT)
module = types.ModuleType("original_skill_eval_tests")
module.__file__ = str(ROOT / "tests/skills/test_skill_eval.py")
exec(compile(source, module.__file__, "exec"), module.__dict__)
result = unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromModule(module))
raise SystemExit(not result.wasSuccessful())
