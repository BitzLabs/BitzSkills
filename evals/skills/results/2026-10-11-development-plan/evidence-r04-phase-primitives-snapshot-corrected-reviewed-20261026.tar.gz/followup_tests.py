from pathlib import Path
import argparse,hashlib,json,os,re,sys,unittest
from unittest.mock import patch
R=Path.cwd();os.umask(0o077);sys.path.insert(0,str(R/'tests/skills'));sys.path.insert(0,str(R/'evals/skills/routing'))
import test_production_heldout_phases as fixture
p=fixture.p
sha=lambda b:hashlib.sha256(b).hexdigest()
class FollowupTests(fixture.PhasePrimitiveTests):
 def evidence(self,value):
  path=OUTPUT/self._testMethodName;path.mkdir(mode=0o700)
  (path/'observation.json').write_bytes(p.io.encoded(value))
 def test_registered_seal_changed_during_scan_is_rejected(self):
  seal=p.io.encoded(dict(version='PUBLIC_SYNTHETIC_SEAL'));(self.f.root/p.SEAL_NAME).write_bytes(seal)
  original=p._read;fired=[]
  def read(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json' and not fired:(root/p.SEAL_NAME).write_bytes(seal+b' ');fired.append(True)
   return raw
  with patch.object(p,'_read',side_effect=read),self.assertRaises(ValueError):p.read_journal(self.f.root,self.raw,2,seal_sha256=sha(seal))
 def test_same_bytes_mtime_change_is_rejected(self):
  original=p._read;fired=[]
  def read(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json' and not fired:
    path=root/'event-0001.json';st=path.stat();os.utime(path,ns=(st.st_atime_ns,st.st_mtime_ns+1000000));fired.append(True)
   return raw
  with patch.object(p,'_read',side_effect=read),self.assertRaises(ValueError):self.snapshot()
 def test_early_event_changed_after_last_second_pass_read_is_rejected(self):
  original=p._read;calls=[]
  def read(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json':
    calls.append(True)
    if len(calls)==2:(root/'event-0001.json').write_bytes((root/'event-0001.json').read_bytes()+b' ')
   return raw
  with patch.object(p,'_read',side_effect=read),self.assertRaises(ValueError):self.snapshot()
  self.assertEqual(len(calls),2)
 def test_named_lock_replaced_after_flock_before_scan_is_rejected(self):
  original=p.fcntl.flock;changed=[];identity={}
  def lock(fd,operation):
   result=original(fd,operation)
   if operation==p.fcntl.LOCK_SH and not changed:
    old=os.fstat(fd);path=self.f.root/'lock';path.rename(self.f.root.parent/'held-old-lock');path.write_bytes(b'');new=path.stat();identity.update(heldInode=old.st_ino,namedInode=new.st_ino);changed.append(True)
   return result
  error=None
  try:
   with patch.object(p.fcntl,'flock',side_effect=lock):self.snapshot()
  except ValueError:error='ValueError'
  self.evidence(dict(rejected=error is not None,**identity))
  self.assertEqual(error,'ValueError','snapshot accepted while held SH lock fd differed from current lock name')
 def test_lock_mode_changed_after_flock_is_rejected(self):
  original=p.fcntl.flock;changed=[]
  def lock(fd,operation):
   result=original(fd,operation)
   if operation==p.fcntl.LOCK_SH and not changed:(self.f.root/'lock').chmod(0o644);changed.append(True)
   return result
  error=None
  try:
   with patch.object(p.fcntl,'flock',side_effect=lock):self.snapshot()
  except ValueError:error='ValueError'
  self.evidence(dict(rejected=error is not None,currentMode=oct((self.f.root/'lock').stat().st_mode&511)))
  self.assertEqual(error,'ValueError','snapshot accepted after lock mode stopped satisfying owner-only contract')
 def test_lock_hardlink_added_during_scan_is_rejected(self):
  original=p._read;fired=[]
  def read(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json' and not fired:os.link(root/'lock',root.parent/'external-lock-link');fired.append(True)
   return raw
  error=None
  try:
   with patch.object(p,'_read',side_effect=read):self.snapshot()
  except ValueError:error='ValueError'
  self.evidence(dict(rejected=error is not None,currentLinks=(self.f.root/'lock').stat().st_nlink))
  self.assertEqual(error,'ValueError','snapshot accepted after lock became hardlinked during scan')
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',required=True,type=Path);args=parser.parse_args();OUTPUT=args.output
 assert OUTPUT.is_absolute() and OUTPUT.parent==R/'.venv' and re.fullmatch(r'r04-phase-primitives-followup-[a-z0-9-]+',OUTPUT.name) and not OUTPUT.exists();OUTPUT.mkdir(mode=0o700)
 suite=unittest.TestSuite(FollowupTests(name) for name in sorted(FollowupTests.__dict__) if name.startswith('test_'))
 with (OUTPUT/'stderr.log').open('w') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 value=dict(count=result.testsRun,failures=len(result.failures),errors=len(result.errors),exitCode=0 if result.wasSuccessful() else 1,testHelperSha256=sha(Path(__file__).read_bytes()),models=0,reservations=0,privateWrites=0,syntheticOnly=True)
 (OUTPUT/'result.json').write_bytes(p.io.encoded(value));print(json.dumps(value));raise SystemExit(value['exitCode'])
