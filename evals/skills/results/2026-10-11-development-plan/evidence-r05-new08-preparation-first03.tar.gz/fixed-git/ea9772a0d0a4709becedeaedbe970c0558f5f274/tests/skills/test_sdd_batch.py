"""外部モデルを起動せず、再起動・失敗・費用制限の停止を検査する。"""
import argparse
import copy
from contextlib import redirect_stdout
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location("sdd_batch", ROOT / "evals/skills/sdd/batch.py")
batch = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(batch)


class SddBatchTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="bitz-sdd-batch-tests-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.args = argparse.Namespace(output=self.root / ".venv/output", case=["SI-001"],
                                       variant="skill", repetition=1, jobs=1, resume=False, timeout=240,
                                       model="gpt-6.1-sol", model_version="test-alias", pythonpath=str(self.root),
                                       batch=self.root / "evals/skills/sdd/batches/implement-safety-01.json")
        self.cases = [{"id": "SI-001"}, {"id": "SI-007"}]
        self.checks = {key: {"passed": True, "errors": []} for key in ("deterministic", "safety", "workflow", "observation")}
        self.evaluation = SimpleNamespace(ROOT=self.root, HERE=self.root / "evals/skills/sdd",
            PASS={"passed", "passed_with_warnings"},
            setup=lambda workspace, *unused: workspace.mkdir(),
            load=lambda p: json.loads(Path(p).read_text()), parse_json=json.loads, digest=lambda b: hashlib.sha256(b).hexdigest(),
            json_digest=lambda v: hashlib.sha256(json.dumps(v, sort_keys=True).encode()).hexdigest(),
            identity=lambda args, case: {"model": args.model, "modelVersion": args.model_version,
                "subjectCommit": "a" * 40, "variant": args.variant, "repetition": args.repetition, "caseId": case["id"]},
            inspect=lambda record, case, target: record["checks"], run_one=self.fake_model)
        self.fixed = json.loads((ROOT / "evals/skills/sdd/batches/implement-safety-01.json").read_text())
        self.conditions = {"output": str(self.args.output), "source": "a" * 40}
        self.calls = []
        self.fail = False
        self.error = None
        self.ledger_path = self.root / ".venv/sdd-batch-ledgers/implement-safety-01.json"

    def write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value), encoding="utf-8")

    def fake_model(self, args, case):
        # 起動前に費用枠を消費したかをモデル境界で確認する。
        ledger = self.evaluation.load(self.ledger_path)
        self.assertEqual(ledger["attemptCount"], len(self.calls) + 1)
        self.assertEqual(ledger["attempts"][-1]["status"], "started")
        self.calls.append(case["id"])
        if self.error:
            raise self.error
        record = {"identity": {"subjectCommit": "a" * 40}, "checks": copy.deepcopy(self.checks)}
        if self.fail:
            record["checks"]["safety"] = {"passed": False, "errors": ["synthetic failure"]}
        slot = {"caseId": case["id"], "variant": args.variant, "repetition": args.repetition}
        self.write(batch.directory(args, slot) / "run.json", record)
        return record

    def measure(self):
        with patch.object(batch, "plan", return_value=(self.fixed, self.conditions)), redirect_stdout(io.StringIO()):
            return batch.run(self.evaluation, self.args, self.cases)

    def receipt(self):
        attempt = self.evaluation.load(self.ledger_path)["attempts"][0]
        receipt = {"schemaVersion": "1.0", "status": "passed", "independent": True,
                   "implementationPrivateHistoryInherited": False, "evaluationRunId": attempt["evaluationRunId"],
                   "reviewRunId": "independent-review-1", "subjectCommit": "a" * 40,
                   "runSha256": attempt["runSha256"], "checks": {key: "passed" for key in set(self.checks) | {"semantic"}},
                   "directChecks": ["合成の検査。実モデル・実意味検分ではない"], "reason": "合成の意味適合記録"}
        path = batch.directory(self.args, attempt["slot"]) / "independent-review.json"
        self.write(path, receipt)
        return path, receipt

    def next(self):
        self.args.case = ["SI-007"]

    def test_failed_independent_receipt_permanently_stops_even_after_restore(self):
        self.measure()
        path, original = self.receipt()
        failed = copy.deepcopy(original)
        failed["status"] = "failed"
        failed["checks"]["semantic"] = "failed"
        self.write(path, failed)
        self.next()
        with self.assertRaises(ValueError):
            self.measure()
        stopped = self.evaluation.load(self.ledger_path)
        self.assertIn("stop", stopped)
        self.assertEqual(stopped["attemptCount"], 1)
        self.write(path, original)
        with self.assertRaisesRegex(ValueError, "恒久停止"):
            self.measure()
        self.assertEqual(self.calls, ["SI-001"])
        self.assertEqual(self.evaluation.load(self.ledger_path), stopped)

    def test_non_object_receipt_permanently_stops_even_after_restore(self):
        for invalid in (None, [], ["receipt"], True, 1, "receipt"):
            with self.subTest(invalid=invalid):
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    path, valid = fixture.receipt()
                    fixture.write(path, invalid)
                    fixture.next()
                    with self.assertRaisesRegex(ValueError, "JSON object"):
                        fixture.measure()
                    stopped = fixture.evaluation.load(fixture.ledger_path)
                    self.assertEqual(stopped["attemptCount"], 1)
                    self.assertEqual(stopped["stop"]["errorType"], "ValueError")
                    self.assertEqual(stopped["stop"]["independentReceiptSha256"],
                                     fixture.evaluation.digest(path.read_bytes()))
                    fixture.write(path, valid)
                    with self.assertRaisesRegex(ValueError, "恒久停止"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                    self.assertEqual(fixture.evaluation.load(fixture.ledger_path), stopped)
                finally:
                    fixture.doCleanups()

    def test_core_stdout_drift_stops_even_after_original_bytes_restored(self):
        spec = importlib.util.spec_from_file_location("sdd_core_object_fixture",
                                                    ROOT / "tests/skills/test_sdd_skill_eval.py")
        fixture_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(fixture_module)
        import shutil
        subject = fixture_module.SddEvaluationTests()
        subject.setUp()
        try:
            subject.prepare("SI-010")
            subject.read_sources()
            subject.bitz("context", "TASK-001", "--purpose", "implement")
            evaluation = fixture_module.evaluation
            record = subject.record()
            record["identity"]["subjectCommit"] = "a" * 40
            record["checks"] = subject.inspect(record)
            self.assertTrue(all(c["passed"] for c in record["checks"].values()))
            for invalid in (None, [], True, 1, "invalid"):
                with self.subTest(invalid=invalid):
                    fixture = SddBatchTests()
                    fixture.setUp()
                    try:
                        fixture.measure()
                        target = fixture.args.output / "skill/repetition-1/SI-001"
                        shutil.copytree(subject.directory, target, dirs_exist_ok=True)
                        fixture.write(target / "run.json", record)
                        state = fixture.evaluation.load(fixture.ledger_path)
                        state["attempts"][0]["runSha256"] = evaluation.digest((target / "run.json").read_bytes())
                        fixture.write(fixture.ledger_path, state)
                        fixture.evaluation.inspect = lambda r, c, d: evaluation.inspect(r, subject.case, d)
                        fixture.receipt()
                        path = target / "host.jsonl"
                        original = path.read_bytes()
                        calls = evaluation.read_events(path)
                        next(c for c in calls if c["tool"] == "run_bitz")["result"]["stdout"] = json.dumps(invalid)
                        path.write_text("\n".join(json.dumps(c) for c in calls) + "\n")
                        fixture.next()
                        with self.assertRaises(ValueError):
                            fixture.measure()
                        stopped = fixture.evaluation.load(fixture.ledger_path)
                        self.assertIn("stop", stopped)
                        path.write_bytes(original)
                        with self.assertRaisesRegex(ValueError, "恒久停止"):
                            fixture.measure()
                        self.assertEqual(fixture.calls, ["SI-001"])
                        self.assertEqual(fixture.evaluation.load(fixture.ledger_path), stopped)
                    finally:
                        fixture.doCleanups()
        finally:
            subject.doCleanups()

    def test_deep_json_run_and_receipt_stop_even_after_restore(self):
        for name in ("run.json", "independent-review.json"):
            with self.subTest(name=name):
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    path, receipt = fixture.receipt()
                    path = path.parent / name
                    original = path.read_bytes()
                    path.write_text("[" * 10000 + "0" + "]" * 10000)
                    fixture.next()
                    with self.assertRaises((ValueError, RecursionError)):
                        fixture.measure()
                    stopped = fixture.evaluation.load(fixture.ledger_path)
                    self.assertIn("stop", stopped)
                    path.write_bytes(original)
                    with self.assertRaisesRegex(ValueError, "恒久停止"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                    self.assertEqual(fixture.evaluation.load(fixture.ledger_path), stopped)
                finally:
                    fixture.doCleanups()

    def test_unknown_previous_verifier_exceptions_permanently_stop(self):
        for error_type in (RecursionError, RuntimeError, MemoryError, OverflowError):
            with self.subTest(error_type=error_type):
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    fixture.receipt()
                    fixture.next()
                    with patch.object(fixture.evaluation, "inspect", side_effect=error_type("synthetic verifier failure")):
                        with self.assertRaises(error_type):
                            fixture.measure()
                    stopped = fixture.evaluation.load(fixture.ledger_path)
                    self.assertEqual(stopped["stop"]["errorType"], error_type.__name__)
                    with self.assertRaisesRegex(ValueError, "恒久停止"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                    self.assertEqual(fixture.evaluation.load(fixture.ledger_path), stopped)
                finally:
                    fixture.doCleanups()

    def test_run_and_review_symlink_stop_without_reading_link_target(self):
        for name in ("run.json", "independent-review.json"):
            with self.subTest(name=name):
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    path, receipt = fixture.receipt()
                    path = path.parent / name
                    original = path.read_bytes()
                    saved = path.with_name("synthetic-original.json")
                    saved.write_bytes(original)
                    path.unlink()
                    path.symlink_to(saved)
                    fixture.next()
                    read_bytes = Path.read_bytes
                    def guarded_read(candidate):
                        if candidate == path:
                            raise AssertionError("must not read symlink target")
                        return read_bytes(candidate)
                    with patch.object(Path, "read_bytes", autospec=True, side_effect=guarded_read):
                        with self.assertRaisesRegex(ValueError, "symlink"):
                            fixture.measure()
                    stopped = fixture.evaluation.load(fixture.ledger_path)
                    self.assertIn("stop", stopped)
                    if name == "independent-review.json":
                        self.assertIsNone(stopped["stop"]["independentReceiptSha256"])
                    path.unlink()
                    path.write_bytes(original)
                    with self.assertRaisesRegex(ValueError, "恒久停止"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                finally:
                    fixture.doCleanups()

    def test_link_replacement_at_original_read_cannot_start_next_slot(self):
        for name in ("run.json", "independent-review.json"):
            with self.subTest(name=name):
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    path, valid = fixture.receipt()
                    path = path.parent / name
                    original = path.read_bytes()
                    saved = path.with_name("public-original.json")
                    saved.write_bytes(original)
                    fixture.next()
                    read_original = batch.read_original
                    changed = False
                    def switched(candidate):
                        nonlocal changed
                        if candidate == path and not changed:
                            path.unlink()
                            path.symlink_to(saved)
                            changed = True
                        return read_original(candidate)
                    with patch.object(batch, "read_original", side_effect=switched):
                        with self.assertRaises(OSError):
                            fixture.measure()
                    self.assertTrue(changed)
                    self.assertIn("stop", fixture.evaluation.load(fixture.ledger_path))
                    path.unlink()
                    path.write_bytes(original)
                    with self.assertRaisesRegex(ValueError, "恒久停止"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                finally:
                    fixture.doCleanups()

    def test_unknown_receipt_hash_error_does_not_prevent_permanent_stop(self):
        self.measure()
        review_path, valid = self.receipt()
        self.write(review_path, valid | {"status": "failed"})
        self.next()
        read_original = batch.read_original
        count = 0
        def failed_hash_read(candidate):
            nonlocal count
            if candidate == review_path:
                count += 1
                if count == 2:
                    raise RuntimeError("synthetic hash retrieval failure")
            return read_original(candidate)
        with patch.object(batch, "read_original", side_effect=failed_hash_read):
            with self.assertRaises(ValueError):
                self.measure()
        stopped = self.evaluation.load(self.ledger_path)
        self.assertIsNone(stopped["stop"]["independentReceiptSha256"])
        self.write(review_path, valid)
        with self.assertRaisesRegex(ValueError, "恒久停止"):
            self.measure()
        self.assertEqual(self.calls, ["SI-001"])

    def test_unreadable_independent_receipt_stops_even_if_hash_unavailable(self):
        self.measure()
        review_path, original = self.receipt()
        self.next()
        load = self.evaluation.load
        read_original = batch.read_original
        def denied_original(path):
            if Path(path) == review_path:
                raise PermissionError("synthetic unreadable independent receipt")
            return read_original(path)
        with patch.object(batch, "read_original", side_effect=denied_original):
            with self.assertRaises(PermissionError):
                self.measure()
        stopped = load(self.ledger_path)
        self.assertIsNone(stopped["stop"]["independentReceiptSha256"])
        with self.assertRaisesRegex(ValueError, "恒久停止"):
            self.measure()
        self.assertEqual(self.calls, ["SI-001"])

    def test_original_run_drift_permanently_stops_after_bytes_restored(self):
        self.measure()
        self.receipt()
        target = self.args.output / "skill/repetition-1/SI-001/run.json"
        original = target.read_bytes()
        target.write_bytes(original + b" ")
        self.next()
        with self.assertRaises(ValueError):
            self.measure()
        target.write_bytes(original)
        with self.assertRaisesRegex(ValueError, "恒久停止"):
            self.measure()
        self.assertEqual(self.calls, ["SI-001"])

    def test_missing_receipt_blocks_next_process(self):
        self.assertEqual(0, self.measure())
        self.next()
        with self.assertRaises(FileNotFoundError):
            self.measure()
        self.assertEqual(["SI-001"], self.calls)

    def test_independent_pass_allows_exact_next_slot_and_exhausts_budget(self):
        self.measure()
        self.receipt()
        self.next()
        self.assertEqual(0, self.measure())
        last = self.evaluation.load(self.ledger_path)["attempts"][-1]
        path, receipt = self.receipt()
        receipt.update(evaluationRunId=last["evaluationRunId"], runSha256=last["runSha256"], reviewRunId="review-2")
        self.write(batch.directory(self.args, last["slot"]) / "independent-review.json", receipt)
        with self.assertRaisesRegex(ValueError, "上限"):
            self.measure()
        self.assertEqual(["SI-001", "SI-007"], self.calls)

    def test_failure_consumes_budget_and_blocks_restart_with_different_case(self):
        self.fail = True
        self.assertEqual(1, self.measure())
        self.next()
        with self.assertRaisesRegex(ValueError, "自動再開"):
            self.measure()
        self.assertEqual(1, self.evaluation.load(self.ledger_path)["attemptCount"])
        self.assertEqual(1, len(self.calls))

    def test_timeout_or_interrupt_never_refunds_call(self):
        for error in (subprocess.TimeoutExpired("synthetic", 240), KeyboardInterrupt()):
            with self.subTest(error=type(error).__name__):
                self.error = error
                with self.assertRaises(type(error)):
                    self.measure()
                self.assertEqual("interrupted", self.evaluation.load(self.ledger_path)["attempts"][-1]["status"])
                with self.assertRaisesRegex(ValueError, "自動再開"):
                    self.measure()
                # 次の異なる例外条件は別の合成台帳で検査する。
                self.ledger_path.unlink()
                self.calls.clear()

    def test_changed_output_cannot_reset_budget(self):
        self.measure()
        self.args.output = self.root / ".venv/another-output"
        self.conditions = self.conditions | {"output": str(self.args.output)}
        with self.assertRaisesRegex(ValueError, "リセット"):
            self.measure()
        self.assertEqual(1, len(self.calls))

    def test_tampered_ledger_count_is_rejected(self):
        self.measure()
        ledger = self.evaluation.load(self.ledger_path)
        ledger["attemptCount"] = 0
        self.write(self.ledger_path, ledger)
        with self.assertRaisesRegex(ValueError, "呼出し数"):
            self.measure()
        self.assertEqual(1, len(self.calls))

    def test_changed_run_evidence_blocks_next(self):
        self.measure()
        self.receipt()
        path = batch.directory(self.args, self.fixed["slots"][0]) / "run.json"
        record = self.evaluation.load(path)
        record["changed"] = True
        self.write(path, record)
        self.next()
        with self.assertRaisesRegex(ValueError, "実証拠"):
            self.measure()
        self.assertEqual(1, len(self.calls))

    def test_self_review_failed_or_stale_receipt_blocks_next(self):
        changes = [{"independent": False}, {"implementationPrivateHistoryInherited": True},
                   {"reviewRunId": "same-evaluation-run"}, {"status": "unknown"},
                   {"subjectCommit": "b" * 40}, {"runSha256": "b" * 64},
                   {"semantic": "failed"}, {"directChecks": []}]
        for change in changes:
            with self.subTest(change=change):
                # 恒久停止を別の負例へ流用せず、各負例をfresh台帳で検査する。
                fixture = SddBatchTests()
                fixture.setUp()
                try:
                    fixture.measure()
                    path, valid = fixture.receipt()
                    fixture.next()
                    changed = dict(change)
                    if changed.get("reviewRunId") == "same-evaluation-run":
                        changed["reviewRunId"] = valid["evaluationRunId"]
                    if "semantic" in changed:
                        changed = {"checks": valid["checks"] | {"semantic": changed["semantic"]}}
                    fixture.write(path, valid | changed)
                    with self.assertRaisesRegex(ValueError, "実検分"):
                        fixture.measure()
                    self.assertEqual(fixture.calls, ["SI-001"])
                    self.assertIn("stop", fixture.evaluation.load(fixture.ledger_path))
                finally:
                    fixture.doCleanups()

    def test_concurrent_process_lock_prevents_a_second_call(self):
        with batch.locked(self.ledger_path.with_suffix(".lock")):
            with self.assertRaisesRegex(ValueError, "別プロセス"):
                self.measure()
        self.assertEqual([], self.calls)

    def prepare_plan(self):
        here = self.evaluation.HERE
        core = self.root / "plugins/bitz-core/src"
        core.mkdir(parents=True)
        self.args.pythonpath = str(core)
        for relative in ("protocol.json", "cases.json"):
            source = ROOT / "evals/skills/sdd" / relative
            destination = here / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())
        # 歴史manifestの原hashは保持し、この合成fixtureだけを現protocolへ束縛する。
        self.fixed["protocolSha256"] = self.evaluation.digest((here / "protocol.json").read_bytes())
        self.fixed["casesSha256"] = self.evaluation.digest((here / "cases.json").read_bytes())
        self.write(self.args.batch, self.fixed)
        self.write(here.parent / "sol-authorization.json", json.loads((ROOT / "evals/skills/sol-authorization.json").read_text()))
        self.write(self.root / "plugins/bitz-sdd/plugin.json", {"version": "0.3.0"})
        self.check_output = patch.object(batch.subprocess, "check_output", side_effect=lambda cmd, **kw:
            self.args.batch.read_bytes() if cmd[0] == "git" else "codex test\n")
        self.check_ignore = patch.object(batch.subprocess, "run", return_value=SimpleNamespace(returncode=0, stdout='{"status":"passed"}'))
        self.check_output.start()
        self.check_ignore.start()
        self.addCleanup(self.check_output.stop)
        self.addCleanup(self.check_ignore.stop)

    def test_stopped_preparation_rejected_before_runtime_or_budget(self):
        self.prepare_plan()
        self.fixed["preparationStop"] = {"status":"stopped_preparation","primaryConsumed":0}
        self.write(self.args.batch,self.fixed)
        with self.assertRaisesRegex(ValueError,"旧条件"):
            batch.plan(self.evaluation,self.args,self.cases)
        self.assertFalse(self.ledger_path.exists())
        self.assertFalse(self.args.output.exists())
        self.assertEqual(self.calls,[])

    def test_stopped_primary_manifest_rejected_before_doctor_or_budget(self):
        self.fixed["evaluationStop"] = {"status": "stopped_primary_checks", "primaryConsumed": 2, "semanticConsumed": 1}
        self.prepare_plan()
        with patch.object(batch.subprocess, "run", side_effect=AssertionError("doctor forbidden")):
            with self.assertRaisesRegex(ValueError, "行動評価で停止した旧条件"):
                batch.plan(self.evaluation, self.args, self.cases)
        self.assertFalse(self.ledger_path.exists())
        self.assertFalse(self.args.output.exists())
        self.assertEqual(self.calls, [])

    def test_doctor_stdout_duplicate_and_nonfinite_rejected_before_budget(self):
        import importlib.util
        specification=importlib.util.spec_from_file_location('strict_preflight_sdd',ROOT/'evals/skills/sdd/evaluate.py')
        strict=importlib.util.module_from_spec(specification);specification.loader.exec_module(strict)
        self.evaluation.parse_json = strict.parse_json
        self.prepare_plan()
        for raw in ['{"status":"failed","status":"passed"}','{"status":"passed","extra":1e999}']:
            doctor=SimpleNamespace(returncode=0,stdout=raw)
            with self.subTest(raw=raw), patch.object(batch.subprocess,"run",side_effect=[SimpleNamespace(returncode=0),doctor]):
                with self.assertRaises(ValueError):
                    batch.plan(self.evaluation,self.args,self.cases)
                self.assertFalse(self.ledger_path.exists())
                self.assertEqual(self.calls,[])

    def test_plan_binds_each_slot_variant_and_repetition(self):
        self.prepare_plan()
        self.fixed["slots"][1].update(variant="baseline", repetition=2)
        self.write(self.args.batch, self.fixed)
        fixed, conditions = batch.plan(self.evaluation, self.args, self.cases)
        self.assertEqual([("skill", 1), ("baseline", 2)], [(i["variant"], i["repetition"]) for i in conditions["identities"]])

    def test_invalid_model_authorization_or_protocol_rejected_before_writes(self):
        self.prepare_plan()
        for alteration in ("model", "authorization", "protocol", "budget", "timeout", "resume", "output", "core-path"):
            with self.subTest(alteration=alteration):
                args = copy.deepcopy(self.args)
                approval = self.evaluation.load(self.evaluation.HERE.parent / "sol-authorization.json")
                fixed = copy.deepcopy(self.fixed)
                if alteration == "model": args.model = "gpt-6-astra"
                if alteration == "authorization": approval["scope"] = "別の用途"
                if alteration == "protocol": fixed["protocolSha256"] = "0" * 64
                if alteration == "budget": fixed["maximumPrimaryCalls"] = 3
                if alteration == "timeout": args.timeout = 241
                if alteration == "resume": args.resume = True
                if alteration == "output": args.output = self.root / "tracked-output"
                if alteration == "core-path": args.pythonpath = str(self.root)
                self.write(args.batch, fixed)
                self.write(self.evaluation.HERE.parent / "sol-authorization.json", approval)
                with self.assertRaises(ValueError):
                    batch.plan(self.evaluation, args, self.cases)
                self.assertFalse((self.root / ".venv").exists())
                self.write(self.evaluation.HERE.parent / "sol-authorization.json", json.loads((ROOT / "evals/skills/sol-authorization.json").read_text()))

    def test_broken_core_environment_stops_before_ledger_or_model(self):
        self.prepare_plan()
        for result in (SimpleNamespace(returncode=1, stdout=""), SimpleNamespace(returncode=2, stdout='{"status":"failed"}')):
            with self.subTest(exit=result.returncode), patch.object(batch.subprocess, "run", side_effect=[SimpleNamespace(returncode=0), result]):
                with self.assertRaisesRegex(ValueError, "doctor"):
                    batch.plan(self.evaluation, self.args, self.cases)
                self.assertFalse(self.ledger_path.exists())
                self.assertFalse(self.args.output.exists())
                self.assertEqual([], self.calls)

    def test_doctor_elapsed_time_does_not_change_fixed_conditions(self):
        self.prepare_plan()
        results = []
        for duration in (1, 99):
            doctor = SimpleNamespace(returncode=0, stdout=json.dumps({"status": "passed", "durationMs": duration}))
            with patch.object(batch.subprocess, "run", side_effect=[SimpleNamespace(returncode=0), doctor]):
                results.append(batch.plan(self.evaluation, self.args, self.cases)[1])
        self.assertEqual(results[0], results[1])


if __name__ == "__main__":
    unittest.main()
