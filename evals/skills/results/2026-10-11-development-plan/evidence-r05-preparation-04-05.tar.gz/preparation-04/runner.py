from pathlib import Path
import sys,json,hashlib,subprocess,os,time,signal
root=Path.cwd();sys.path.insert(0,str(root/'evals/skills/routing'))
import production_canary_capture as capture,production_canary_evidence as evidence,production_canary_score as score,production_ledger as ledger,production_review_ledger as static,run_sdk_trace_review as review
source='9518ec7b917e5490a48b8021a1aa7faa33f6a087'
assert capture.guard.git(root,'status','--porcelain')==b''
assert capture.guard.git(root,'rev-parse','HEAD').decode().strip()==source
bound,_=capture.prepare(source);fixed=evidence.load_fixed_inputs(root,source)
predecessors=ledger.verify_predecessor(root,bound.contract)
assert not (root/'.venv/sdd-batch-ledgers/plan-implement-matrix-20261012-04.json').exists()
base=root/'.venv/r05-matrix-prelaunch-sol-04';base.mkdir(mode=0o700)
for name in ['work','tmp','codex-home','state','logs']:(base/name).mkdir(mode=0o700)
files=['evals/skills/sdd/evaluate.py', 'evals/skills/sdd/batch.py', 'evals/skills/sdd/protocol.json', 'evals/skills/sdd/batches/plan-implement-matrix-20261012-04.json', 'evals/skills/sdd/cases.json', 'evals/skills/sdd/decision.schema.json', 'plugins/bitz-sdd/skills/sdd-implement/SKILL.md', 'plugins/bitz-sdd/skills/sdd-implement/references/execution.md', 'plugins/bitz-sdd/skills/sdd-implement/references/safety-and-recovery.md', 'plugins/bitz-sdd/skills/sdd-implement/references/handoff.md', 'plugins/bitz-sdd/skills/sdd-plan/SKILL.md', 'tests/skills/test_sdd_native_completion.py', 'tests/skills/test_sdd_batch.py']
contract=dict(model='gpt-6.1-sol',maximumInvocations=1,automaticRetries=0,primaryModelTrajectories=0,independentReviewerSol=1,timeoutSeconds=300,sourceCommit=source,scope='public-sdd-matrix-prelaunch-static-only',payloadFiles=files,outputRelativeRoot=str(base.relative_to(root)),contractProvenance='ignored parent-fixed bytes at recorded SHA, public source bytes from exact Git ref; no claim contract is Git tracked',limits=['no tools/files/tests/delegation','old stopped campaigns and preparation01/02 preserved','one preparation review distinct from primary68/semantic68','no actual exec-wait/MCP transport certification'])
contract_raw=ledger.encoded(contract);ledger.exclusive(base/'contract.json',contract_raw)
script=Path(__file__).read_bytes();ledger.exclusive(base/'runner.py',script)

prompt='あなたは履歴を継承しない独立した静的コード検分者です。以下の確定公開本文だけを検分します。tool・ファイル読取り・試験実行・追加モデル・委譲は禁止。実行していない試験を実行済みと書かない。SDDの新04有限行列は計画7/実装10×skill/baseline×2反復で68枠、各240秒/retry0/逐次、各一次後の独立意味receiptと原証拠照合が次枠の前提です。今回の準備検分は独立1枠で、一次68/後続意味独立68とは別です。旧01はCore stdoutの不正JSON、旧02は非object receipt、旧03は非object Core stdoutのAttributeErrorが恒久stopを迂回するP2で準備各1・一次0のまま停止しました。原hash不一致は内容検査より前に拒否し、Core非objectは不正結果、構造AttributeErrorも不適合として恒久stopまたは当件原失敗保存へ送ります。新04はreceiptのdict型検査からValueErrorを投げ同ロック内で恒久stopを保存します。未提出だけpending、提出された不適合/原不整合は永久stopで、正常receiptへ復元しても起動しません。null/配列/真偽値/数値/文字列をfresh合成台帳で回帰します。実行版0.1.4では固定CLI0.160.1の単一turn/許可MCP/正常終端/usage/固定原artifactを照合し、全JSON入口の重複キーと非有限値を拒否します。親はclean refの全695試験を実行しました。それはあなたの試験実行ではありません。新一次は未起動で旧結果を新Gate成功へ付け替えません。この範囲で起動を阻害する具体的で再現可能なP1/P2/P3欠陥を示し、一般論や明示された未認定範囲だけを欠陥扱いしないでください。JSONだけを返してください。\n'+f'sourceCommit={source}\nscope={contract["scope"]}\n'

payload_hashes={}
for name in files:
    raw=capture.guard.git(root,'show',source+':'+name);payload_hashes[name]=ledger.sha(raw)
    prompt+=f'\nFILE {name} SHA256 {ledger.sha(raw)}\n'+'\n'.join(f'{i}: {line}' for i,line in enumerate(raw.decode().splitlines(),1))+'\nEND FILE\n'
prompt_raw=prompt.encode();ledger.exclusive(base/'prompt.txt',prompt_raw)
schema_value=json.loads(capture.guard.git(root,'show',source+':evals/skills/routing/sdk-trace-review.schema.json'));schema_value['properties']['scope']['enum']=[contract['scope']];schema=ledger.encoded(schema_value);ledger.exclusive(base/'schema.json',schema)
reservation=static.reserve_static_review(root,'evals/skills/routing/sdk-trace-review-v0.46.json',source,contract_raw);ledger.exclusive(base/'reservation.json',ledger.encoded(reservation))
config=score.config_for(base);ledger.exclusive(base/'config.json',ledger.encoded(config))
cmd=score.command_for(base,bound.contract)
cmd=[str(base/'schema.json') if arg==str(base/'execution-schema.json') else arg for arg in cmd]
before=capture.guard.verify(root,source,files);runtime_raw=(root/capture.fixed_runtime.MANIFEST).read_bytes();runtime_before=capture.fixed_runtime.verify(runtime_raw,bound.contract)
ledger.exclusive(base/'invocation.json',ledger.encoded(dict(argv=cmd,sourceCommit=source,contractSha256=ledger.sha(contract_raw),runnerSha256=ledger.sha(script),promptSha256=ledger.sha(prompt_raw),payloadSha256=payload_hashes,maximumInvocations=1,automaticRetries=0)))
started=time.monotonic();out=err=b'';code=None;timed=False;error=None;usage=None;response=None;warnings=[];invocations=0
try:
    auth=Path('/home/hide/.codex/auth.json');assert auth.is_file() and not auth.is_symlink()
    env=dict(PATH=str(Path(bound.contract['codexPath']).parents[1]/'bin')+':/usr/bin:/bin',LANG='C.UTF-8',TMPDIR=str(base/'tmp'))
    p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True);invocations=1
    try:out,err=p.communicate(prompt_raw,timeout=300)
    except subprocess.TimeoutExpired:
        timed=True;os.killpg(p.pid,signal.SIGTERM)
        try:out,err=p.communicate(timeout=3)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
    code=p.returncode
except BaseException as exc:error=type(exc).__name__+': '+str(exc)
ledger.exclusive(base/'trace.jsonl',out);ledger.exclusive(base/'stderr.bin',err)
try:
    if code==0 and not timed:response,usage,warnings=review.review_response(base,out,source,schema,contract)
except BaseException as exc:error=type(exc).__name__+': '+str(exc)
after=None;runtime_after=None;predecessors_after=None;after_error=None
try:
    after=capture.guard.verify(root,source,files)
    runtime_after=capture.fixed_runtime.verify(runtime_raw,bound.contract)
    predecessors_after=ledger.verify_predecessor(root,bound.contract)
except Exception as exc:
    after_error=type(exc).__name__+': '+str(exc);error=error or after_error

receipt=dict(status='static_sdd_prelaunch_review_passed' if code==0 and not timed and error is None and response and response['verdict']=='pass' else 'static_prelaunch_review_stopped',sourceCommit=source,maximumInvocations=1,consumedReservations=1,actualInvocations=invocations,primaryModelTrajectories=0,automaticRetries=0,exitCode=code,timedOut=timed,error=error,afterVerificationError=after_error,elapsedSeconds=time.monotonic()-started,usage=usage,sourceBefore=before,sourceAfter=after,runtimeUnchanged=runtime_before==runtime_after,predecessorsUnchanged=predecessors==predecessors_after,newPrimaryLedgerExists=(root/'.venv/sdd-batch-ledgers/plan-implement-matrix-20261012-04.json').exists(),response=response,acceptedStartupWarningHashes=warnings,certifiesBehavior=False,certifiesSkillGate=False,scope='public-static-sdd-prelaunch-only',artifactSha256={p.name:ledger.sha(ledger.read_regular(p)) for p in base.iterdir() if p.is_file()})
ledger.exclusive(base/'receipt.json',ledger.encoded(receipt));print(json.dumps({k:v for k,v in receipt.items() if k not in ['sourceBefore','sourceAfter','artifactSha256']},ensure_ascii=False))
