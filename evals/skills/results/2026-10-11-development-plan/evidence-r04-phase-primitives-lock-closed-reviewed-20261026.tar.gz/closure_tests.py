from pathlib import Path
import argparse,hashlib,json,os,re,sys,unittest
from unittest.mock import patch
R=Path.cwd();os.umask(0o077);sys.path.insert(0,str(R/'tests/skills'));sys.path.insert(0,str(R/'evals/skills/routing'))
import test_production_heldout_phases as fixture
p=fixture.p
sha=lambda b:hashlib.sha256(b).hexdigest()
class ClosureTests(fixture.PhasePrimitiveTests):
 def test_zero_byte_lock_size_drift_at_context_exit_is_rejected(self):
  with self.assertRaises(ValueError):
   with p.journal_read_lock(self.f.root):(self.f.root/'lock').write_bytes(b'x')
 def test_symlinked_lock_name_at_context_exit_is_rejected(self):
  original=self.f.root.parent/'original-lock'
  with self.assertRaises(ValueError):
   with p.journal_read_lock(self.f.root):
    path=self.f.root/'lock';path.rename(original);path.symlink_to(original)
 def test_body_exception_propagates_and_closes_both_readonly_fds(self):
  before={f.name:f.read_bytes() for f in self.f.root.iterdir()};seen=[];directory=None
  original=p.fcntl.flock
  def locked(fd,operation):seen.append(fd);return original(fd,operation)
  class SyntheticError(Exception):pass
  with patch.object(p.fcntl,'flock',side_effect=locked),self.assertRaises(SyntheticError):
   with p.journal_read_lock(self.f.root) as directory:raise SyntheticError()
  self.assertEqual(len(seen),1)
  for fd in [directory,*seen]:
   with self.assertRaises(OSError):os.fstat(fd)
  self.assertEqual(before,{f.name:f.read_bytes() for f in self.f.root.iterdir()})
 def test_original_read_error_closes_lock_and_directory_without_writes(self):
  before={f.name:f.read_bytes() for f in self.f.root.iterdir()};locks=[];directories=[];original=p.fcntl.flock
  def locked(fd,operation):locks.append(fd);return original(fd,operation)
  def fail(root,name,**kwargs):directories.append(kwargs['directory']);raise OSError('PUBLIC_SYNTHETIC_READ_ERROR')
  with patch.object(p.fcntl,'flock',side_effect=locked),patch.object(p,'_read',side_effect=fail),self.assertRaises(OSError):self.snapshot()
  self.assertEqual((len(locks),len(directories)),(1,1))
  for fd in [*locks,*directories]:
   with self.assertRaises(OSError):os.fstat(fd)
  self.assertEqual(before,{f.name:f.read_bytes() for f in self.f.root.iterdir()})
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',required=True,type=Path);args=parser.parse_args();out=args.output
 assert out.is_absolute() and out.parent==R/'.venv' and re.fullmatch(r'r04-phase-primitives-closure-[a-z0-9-]+',out.name) and not out.exists();out.mkdir(mode=0o700)
 suite=unittest.TestSuite(ClosureTests(name) for name in sorted(ClosureTests.__dict__) if name.startswith('test_'))
 with (out/'stderr.log').open('w') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 value=dict(count=result.testsRun,failures=len(result.failures),errors=len(result.errors),exitCode=0 if result.wasSuccessful() else 1,testHelperSha256=sha(Path(__file__).read_bytes()),models=0,reservations=0,privateWrites=0,syntheticOnly=True)
 (out/'result.json').write_bytes(p.io.encoded(value));print(json.dumps(value));raise SystemExit(value['exitCode'])
