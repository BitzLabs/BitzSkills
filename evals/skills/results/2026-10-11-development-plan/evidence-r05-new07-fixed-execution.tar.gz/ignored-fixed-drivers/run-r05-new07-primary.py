"""固定した新07の次枠1件だけ。実呼出しの前後に原条件を保存する。"""
from pathlib import Path
import os, sys, json, subprocess, time, hashlib, importlib.util
root = Path.cwd()
source = '915fae1290cb632cd53f6b7fcfb906d5c98b2e30'
sys.path.insert(0, str(root / 'evals/skills/routing'))
import production_ledger as original_io

def read_raw(path):
    return original_io.read_regular(Path(path).absolute())
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
ordinal = int(sys.argv[1])
assert 1 <= ordinal <= 68
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
sha = lambda p: hashlib.sha256(read_raw(p)).hexdigest()
prep = root / '.venv/r05-matrix-prelaunch-sol-07'
import ast
import production_canary_capture as capture
import production_canary_score as score
import production_trace as trace
import run_sdk_trace_review as review
bound, _ = capture.prepare(source)

# Unspent driver only: pin the trusted preparation builder; never execute its I/O/model nodes.
def preparation_expected():
    builder = read_raw(root / '.venv/r05-prelaunch-sol-review-07.py')
    assert original_io.sha(builder) == '91ef204afb1d5ee34316231a5b746ff503f5c987452a5da18ccc88a335196d6c'
    selected = []
    for node in ast.parse(builder).body:
        targets = node.targets if isinstance(node, ast.Assign) else [node.target] if isinstance(node, ast.AugAssign) else []
        if any(isinstance(target, ast.Name) and target.id in {'files', 'contract', 'prompt'} for target in targets):
            selected.append(node)
    ns = dict(root=root, base=prep, source=source)
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<pinned preparation literals>', 'exec'), ns)
    files, contract, prompt = ns['files'], ns['contract'], ns['prompt']
    assert len(files) == len(set(files)) == 20
    payload = {}
    for name in files:
        raw = capture.guard.git(root, 'show', source + ':' + name)
        payload[name] = original_io.sha(raw)
        prompt += f'\nFILE {name} SHA256 {original_io.sha(raw)}\n' + '\n'.join(f'{i}: {line}' for i, line in enumerate(raw.decode().splitlines(), 1)) + '\nEND FILE\n'
    schema = trace.strict_json(capture.guard.git(root, 'show', source + ':evals/skills/routing/sdk-trace-review.schema.json'))
    schema['properties']['scope']['enum'] = [contract['scope']]
    argv = score.command_for(prep, bound.contract)
    argv = [str(prep / 'schema.json') if arg == str(prep / 'execution-schema.json') else arg for arg in argv]
    return builder, files, contract, prompt.encode(), payload, original_io.encoded(schema), argv


def verify_preparation():
    receipt_raw = read_raw(prep / 'receipt.json')
    receipt = trace.strict_json(receipt_raw)
    assert isinstance(receipt, dict)
    names = {'config.json', 'contract.json', 'invocation.json', 'prompt.txt', 'reservation.json', 'runner.py', 'schema.json', 'stderr.bin', 'trace.jsonl', 'response.json'}
    assert isinstance(receipt.get('artifactSha256'), dict) and set(receipt['artifactSha256']) == names, 'preparation closed10'
    originals = {name: read_raw(prep / name) for name in sorted(names)}
    assert receipt['artifactSha256'] == {name: original_io.sha(raw) for name, raw in originals.items()}
    for name, value in {'maximumInvocations':1,'consumedReservations':1,'actualInvocations':1,'primaryModelTrajectories':0,'automaticRetries':0,'exitCode':0}.items():
        assert type(receipt[name]) is int and receipt[name] == value, name
    for name in ('timedOut','newPrimaryLedgerExists','certifiesBehavior','certifiesSkillGate'):
        assert receipt[name] is False, name
    for name in ('runtimeUnchanged','predecessorsUnchanged'):
        assert receipt[name] is True, name
    assert receipt['error'] is None and receipt['afterVerificationError'] is None and receipt['artifactReadErrors'] == {}
    assert receipt['status'] == 'static_sdd_prelaunch_review_passed' and receipt['sourceCommit'] == source
    assert receipt['scope'] == 'public-static-sdd-prelaunch-only'
    builder, files, contract, prompt, payload, schema, argv = preparation_expected()
    contract_raw = original_io.encoded(contract)
    for name, expected in {'runner.py':builder,'contract.json':contract_raw,'prompt.txt':prompt,'schema.json':schema,'config.json':original_io.encoded(score.config_for(prep))}.items():
        assert originals[name] == expected, 'preparation fixed bytes: ' + name
    invocation = dict(argv=argv, sourceCommit=source, contractSha256=original_io.sha(contract_raw), runnerSha256=original_io.sha(builder), promptSha256=original_io.sha(prompt), payloadSha256=payload, maximumInvocations=1, automaticRetries=0)
    assert originals['invocation.json'] == original_io.encoded(invocation), 'preparation invocation'
    state = capture.guard.verify(root, source, files)
    assert original_io.encoded(receipt['sourceBefore']) == original_io.encoded(state) == original_io.encoded(receipt['sourceAfter']), 'preparation Git20'
    reservation_path = original_io.common_ledger_path(root).parent / 'production-routing-static-review-ledger/sdk-trace-review-v0.49.json'
    shared_raw = read_raw(reservation_path)
    shared = dict(contractPath='evals/skills/routing/sdk-trace-review-v0.49.json', sourceCommit=source, contractSha256=original_io.sha(contract_raw), maximumInvocations=1, consumedReservations=1, automaticRetry=False, primaryModelTrajectories=0, model='gpt-6.1-sol')
    assert shared_raw == original_io.encoded(shared), 'preparation shared reservation'
    assert originals['reservation.json'] == original_io.encoded(dict(path=str(reservation_path), sha256=original_io.sha(shared_raw), **shared)), 'preparation reservation original'
    class ResponseBytes:
        def read_bytes(self):
            return originals['response.json']
    class NativeView:
        def __truediv__(self, name):
            assert name == 'response.json'
            return ResponseBytes()
    response, usage, warnings = review.review_response(NativeView(), originals['trace.jsonl'], source, schema, contract)
    assert response['verdict'] == 'pass' and response['findings'] == []
    assert original_io.encoded(receipt['response']) == original_io.encoded(response)
    assert original_io.encoded(receipt['usage']) == original_io.encoded(usage)
    assert receipt['acceptedStartupWarningHashes'] == warnings
    return receipt, original_io.sha(receipt_raw)

receipt, preparation_receipt_sha = verify_preparation()
manifest = root / 'evals/skills/sdd/batches/plan-implement-matrix-20261012-07.json'
batch = json.loads(read_raw(manifest))
assert batch['maximumPrimaryCalls'] == 68 and 'preparationStop' not in batch and 'evaluationStop' not in batch
slot = batch['slots'][ordinal - 1]
lp = root / '.venv/sdd-batch-ledgers' / (batch['id'] + '.json')
if lp.exists():
    ledger = json.loads(read_raw(lp))
    assert ledger['attemptCount'] == ordinal - 1 and 'stop' not in ledger
else:
    assert ordinal == 1
integration = root.parents[1]
node = integration / '.venv/fixed-codex-0.160.1'
codex = node / 'bin/codex'
assert subprocess.check_output([str(codex), '--version'], env=dict(os.environ, PATH=str(node / 'bin') + ':/usr/bin:/bin'), text=True).strip() == 'codex-cli 0.160.1'
pythonpath = str(root / 'plugins/bitz-core/src') + ':' + str(root / 'plugins/bitz-core/.venv/lib/python3.12/site-packages') + ':/usr/lib/python3/dist-packages'
output = root / '.venv/sdd-plan-implement-matrix-20261012-07'
argv = ['/usr/bin/python3', '-B', 'evals/skills/sdd/evaluate.py', 'run', '--batch', str(manifest), '--variant', slot['variant'], '--repetition', str(slot['repetition']), '--model', 'gpt-6.1-sol', '--model-version', 'unversioned-alias-observed-2026-10-13', '--pythonpath', pythonpath, '--output', str(output), '--case', slot['caseId'], '--jobs', '1', '--timeout', '240']
base = root / '.venv/r05-new07-primary-process' / f'attempt-{ordinal:02d}'
base.mkdir(parents=True, exist_ok=False)
config = dict(argv=argv, sourceCommit=source, slot=slot, ordinal=ordinal, maximumPrimaryCalls=68, automaticRetries=0, preparationReceiptSha256=preparation_receipt_sha, manifestSha256=sha(manifest), runnerSha256=sha(Path(__file__)), providerCost=None)
(base / 'command.json').write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n')
env = dict(os.environ, PATH=str(node / 'bin') + ':/home/hide/.local/bin:/usr/bin:/bin', PYTHONPATH=pythonpath, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(root / '.venv/test-temp'))
started = time.monotonic()
code = None
error = None
with (base / 'stdout').open('xb') as stdout, (base / 'stderr').open('xb') as stderr:
    try:
        code = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=300).returncode
    except BaseException as exc:
        error = type(exc).__name__ + ': ' + str(exc)
post_errors = {}
def stored_hash(path):
    try:
        return sha(path)
    except Exception as exc:
        post_errors[str(path)] = type(exc).__name__ + ': ' + str(exc)
        return None
summary = dict(exitCode=code, error=error, seconds=time.monotonic()-started,
               sourceCommit=source, slot=slot, ordinal=ordinal,
               stdoutSha256=stored_hash(base/'stdout'), stderrSha256=stored_hash(base/'stderr'),
               cleanAfter=None, gateDecision='not-certified')
try:
    summary['cleanAfter'] = subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
    if lp.exists():
        ledger_state = json.loads(read_raw(lp))
        summary['ledgerSha256'] = stored_hash(lp)
        summary['attemptCount'] = ledger_state['attemptCount']
        summary['attempts'] = ledger_state['attempts']
except Exception as exc:
    post_errors['source-or-ledger'] = type(exc).__name__ + ': ' + str(exc)
target = output / slot['variant'] / f"repetition-{slot['repetition']}" / slot['caseId']
summary['artifacts'] = {}
for name in ('run.json','failure.json','trace.jsonl','host.jsonl','changes.json','decision.json',
             'control.json','stderr.log','prompt.txt','invocation.json'):
    path = target / name
    try:
        if path.exists() or path.is_symlink():
            summary['artifacts'][name] = stored_hash(path)
    except Exception as exc:
        post_errors[name] = type(exc).__name__ + ': ' + str(exc)
summary['postVerificationErrors'] = post_errors
if post_errors:
    summary['error'] = summary['error'] or 'original process/ledger/artifact verification failed'
(base / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))
sys.exit(code if code is not None and not post_errors else 1)
