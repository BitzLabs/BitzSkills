"""各実一次と別文脈SOL原証拠の照合。モデル/予約/同条件retryを行わない。"""
from pathlib import Path
import sys,json,subprocess
root=Path.cwd();sys.path.insert(0,str(root/'evals/skills/routing'));sys.path.insert(0,str(root/'evals/skills/sdd'))
import production_ledger as io,run_sdk_trace_review as native,evaluate as evaluation
source='915fae1290cb632cd53f6b7fcfb906d5c98b2e30'
def raw(p):return io.read_regular(Path(p).absolute())
def load(p):return io.strict_json(raw(p))
def sha(p):return io.sha(raw(p))
ordinal=int(sys.argv[1]);assert 1<=ordinal<=68
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert subprocess.check_output(['git','status','--porcelain'])==b''
manifest=load(root/'evals/skills/sdd/batches/plan-implement-matrix-20261012-07.json');slot=manifest['slots'][ordinal-1]
process=root/'.venv/r05-new07-primary-process'/f'attempt-{ordinal:02d}'
target=root/'.venv/sdd-plan-implement-matrix-20261012-07'/slot['variant']/f"repetition-{slot['repetition']}"/slot['caseId']
base=root/'.venv/r05-new07-semantic'/f'attempt-{ordinal:02d}'
summary=load(process/'summary.json');run=load(target/'run.json');ledger=load(root/'.venv/sdd-batch-ledgers'/f"{manifest['id']}.json")
assert ledger['attemptCount']==ordinal and len(ledger['attempts'])==ordinal and 'stop' not in ledger
attempt=ledger['attempts'][-1];assert attempt['slot']==slot and attempt['status']=='completed'
assert summary['exitCode']==0 and summary['error'] is None and summary['cleanAfter'] and not summary['postVerificationErrors']
assert summary['ordinal']==ordinal and summary['sourceCommit']==source and summary['slot']==slot
assert sha(target/'run.json')==attempt['runSha256']==summary['artifacts']['run.json']
for name in ['stdout','stderr']:assert sha(process/name)==summary[name+'Sha256']
assert run['identity']['subjectCommit']==source and all(v['passed'] for v in run['checks'].values())
case=next(c for c in evaluation.load(root/'evals/skills/sdd/cases.json') if c['id']==slot['caseId'])
assert evaluation.inspect(run,case,target)==run['checks']
import production_canary_capture as capture, production_canary_score as score
bound,_=capture.prepare(source)
assert set(run['artifacts'])=={'trace.jsonl','host.jsonl','changes.json','decision.json','control.json','stderr.log','prompt.txt','invocation.json'}
for name,h in run['artifacts'].items():assert sha(target/name)==h==summary['artifacts'][name]
changes=load(target/'changes.json');assert evaluation.snapshot(target/'workspace')==changes['after']
receipt=load(base/'receipt.json');contract=load(base/'contract.json');invocation=load(base/'invocation.json');independent=load(target/'independent-review.json')
assert receipt['status']=='passed' and receipt['sourceCommit']==source and receipt['ordinal']==ordinal
assert receipt['actualInvocations']==receipt['maximumInvocations']==receipt['consumedReservations']==1 and receipt['automaticRetries']==0
assert receipt['exitCode']==0 and not receipt['timedOut'] and receipt['error'] is None and not receipt['artifactReadErrors']
assert receipt['originalsUnchanged'] and receipt['runtimeUnchanged'] and not receipt['implementationPrivateHistoryInherited']
expected={'config.json','contract.json','invocation.json','prompt.txt','reservation.json','runner.py','schema.json','stderr.bin','trace.jsonl','response.json','parent-direct-checks.json'}
assert set(receipt['artifactSha256'])==expected
for name,h in receipt['artifactSha256'].items():assert sha(base/name)==h
assert contract['ordinal']==ordinal and contract['batchId']==manifest['id'] and contract['sourceCommit']==source
assert contract['evaluationRunId']==attempt['evaluationRunId'] and contract['runSha256']==attempt['runSha256']
assert contract['maximumInvocations']==contract['maximumPerPrimary']==1 and contract['maximumSemanticReviewsForBatch']==68 and contract['automaticRetries']==0
assert contract['manifestSha256']==sha(root/'evals/skills/sdd/batches/plan-implement-matrix-20261012-07.json')
case=next(c for c in evaluation.load(root/'evals/skills/sdd/cases.json') if c['id']==slot['caseId'])
assert invocation['sourceCommit']==source and invocation['maximumInvocations']==1 and invocation['automaticRetries']==0
assert sha(base/'runner.py')==sha(root/'.venv/run-r05-new07-semantic.py')=='23a8de702c27246901d2cc679980d9aff20334ed0f717ff69c5d42feb5c25038'
assert set(invocation)=={'argv','automaticRetries','maximumInvocations','payloadSha256','promptSha256','sourceCommit'}
assert raw(base/'config.json')==io.encoded(score.config_for(base))
expected_argv=score.command_for(base,bound.contract)
expected_argv=[str(base/'schema.json') if a==str(base/'execution-schema.json') else a for a in expected_argv]
assert invocation['argv']==expected_argv
assert invocation['promptSha256']==sha(base/'prompt.txt')
assert set(invocation['payloadSha256'])==set(contract['payloadFiles'])
for name,h in invocation['payloadSha256'].items():
 if name.startswith('primary/'):value=raw(target/name.removeprefix('primary/'))
 elif name.startswith('source/'):value=subprocess.check_output(['git','show',source+':'+name.removeprefix('source/')])
 elif name.startswith('final-workspace/'):value=raw(target/'workspace'/name.removeprefix('final-workspace/'))
 elif name=='public-case.json':value=io.encoded(case)
 elif name=='parent-direct-checks.json':value=raw(base/name)
 else:raise AssertionError('unexpected payload '+name)
 assert io.sha(value)==h,name
class File:
 def read_bytes(self):return raw(base/'response.json')
class View:
 def __truediv__(self,name):
  assert name=='response.json';return File()
response,usage,warnings=native.review_response(View(),raw(base/'trace.jsonl'),source,raw(base/'schema.json'),contract)
assert response==receipt['response'] and usage==receipt['usage'] and warnings==receipt['acceptedStartupWarningHashes']
assert response['verdict']=='pass' and response['semantic']=='passed' and response['findings']==[] and all(v=='passed' for v in response['checks'].values())
reservation=load(base/'reservation.json');assert sha(Path(reservation['path']))==reservation['sha256']
expected_reservation_path=io.common_ledger_path(root).parent/'sdd-semantic-review-ledgers'/manifest['id']/f'sdk-trace-review-v0.{ordinal}.json'
assert reservation['path']==str(expected_reservation_path)
expected_reservation=dict(contractPath=f'evals/skills/routing/sdk-trace-review-v0.{ordinal}.json',sourceCommit=source,contractSha256=sha(base/'contract.json'),maximumInvocations=1,consumedReservations=1,automaticRetry=False,primaryModelTrajectories=0,model='gpt-6.1-sol')
assert raw(expected_reservation_path)==io.encoded(expected_reservation)
assert raw(base/'reservation.json')==io.encoded(dict(path=str(expected_reservation_path),sha256=sha(expected_reservation_path),**expected_reservation))
assert reservation['sourceCommit']==source and reservation['consumedReservations']==1 and reservation['contractSha256']==sha(base/'contract.json')
assert independent['status']=='passed' and independent['independent'] and not independent['implementationPrivateHistoryInherited']
assert independent['subjectCommit']==source and independent['evaluationRunId']==attempt['evaluationRunId']
assert independent['runSha256']==attempt['runSha256'] and independent['checks']==response['checks']
assert independent['semanticReceiptSha256']==sha(base/'receipt.json') and independent['semanticReceiptRelativePath']==str((base/'receipt.json').relative_to(root))
assert independent['reviewRunId']!='' and independent['reviewRunId']!=attempt['evaluationRunId']
direct=load(base/'parent-direct-checks.json');assert direct['checks']==run['checks'] and direct['runSha256']==attempt['runSha256']
proof={'status':'passed','sourceCommit':source,'ordinal':ordinal,'slot':slot,'checks':response['checks'],'primaryRunSha256':attempt['runSha256'],'independentReviewSha256':sha(target/'independent-review.json'),'semanticReceiptSha256':sha(base/'receipt.json'),'primaryUsage':run['providerUsage'],'semanticUsage':usage,'providerCost':None,'primaryProcessSeconds':summary['seconds'],'semanticProcessSeconds':receipt['elapsedSeconds'],'finalSnapshotVerified':True,'primaryOriginalCount':9,'semanticOriginalCount':11,'payloadCount':len(invocation['payloadSha256']),'parentVerifierSha256':sha(Path(__file__)),'eligibleForNextSlot':ordinal<68,'certifiesSkillGate':False,'certifiesRelease':False}
folder=root/'.venv/r05-new07-parent-verifications';folder.mkdir(mode=0o700,exist_ok=True);io.exclusive(folder/f'attempt-{ordinal:02d}.json',io.encoded(proof))
public=Path('/home/hide/BitzLabs/BitzSkills/.venv/skills-integration-worktree/evals/skills/results/2026-10-11-development-plan')
p=public/f'r05-new07-attempt-{ordinal:02d}.json'
prior=json.loads(p.read_text()) if p.exists() else {}
prior.update(status='primary_and_semantic_passed_parent_originals_verified',sourceCommit=source,ordinal=ordinal,slot=slot,semantic='passed',verification=proof)
p.write_text(json.dumps(prior,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False))
