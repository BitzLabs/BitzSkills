from pathlib import Path
import sys,json,datetime,subprocess
from zoneinfo import ZoneInfo
root=Path.cwd();sys.path.insert(0,str(root/'evals/skills/routing'));import production_ledger as io
source='915fae1290cb632cd53f6b7fcfb906d5c98b2e30'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert subprocess.check_output(['git','status','--porcelain'])==b''
def load(p):return io.strict_json(io.read_regular(p.absolute()))
manifest=load(root/'evals/skills/sdd/batches/plan-implement-matrix-20261012-07.json')
lp=root/'.venv/sdd-batch-ledgers'/f"{manifest['id']}.json";ledger=load(lp)
proofs=[]
for n in range(1,69):
 p=root/'.venv/r05-new07-parent-verifications'/f'attempt-{n:02d}.json'
 if p.exists():
  proof=load(p);assert proof['sourceCommit']==source and proof['ordinal']==n and proof['status']=='passed';proofs.append(proof)
assert [p['ordinal'] for p in proofs]==list(range(1,len(proofs)+1))
semantic_storage=io.common_ledger_path(root).parent/'sdd-semantic-review-ledgers'/manifest['id']
semantic_reservations=[];semantic_receipts=[];primary_usage=[]
for n,attempt in enumerate(ledger['attempts'],1):
 slot=manifest['slots'][n-1];assert attempt['slot']==slot
 target=root/'.venv/sdd-plan-implement-matrix-20261012-07'/slot['variant']/f"repetition-{slot['repetition']}"/slot['caseId']
 p=target/'run.json'
 if p.exists():
  run=load(p);assert run['identity']['subjectCommit']==source
  if run.get('providerUsage') is not None:primary_usage.append(run['providerUsage'])
 p=semantic_storage/f'sdk-trace-review-v0.{n}.json'
 if p.exists():
  reserved=load(p);assert reserved['sourceCommit']==source and reserved['consumedReservations']==1;semantic_reservations.append(n)
 p=root/'.venv/r05-new07-semantic'/f'attempt-{n:02d}'/'receipt.json'
 if p.exists():
  receipt=load(p);assert receipt['ordinal']==n and receipt['sourceCommit']==source;semantic_receipts.append(receipt)
def usage(values):
 totals={}
 for record in values:
  for key,value in record.items():
   if type(value) is int:totals[key]=totals.get(key,0)+value
 return {'availableUsageRecords':len(values),'totalsOfAvailableRecords':totals,'providerCost':None}
semantic_usage=[v['usage'] for v in semantic_receipts if v.get('usage') is not None]
record={'status':'stopped' if 'stop' in ledger else ('finite_matrix_complete_pending_independent_aggregate' if len(proofs)==68 else 'finite_matrix_in_progress'),'sourceCommit':source,'updatedAt':datetime.datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(),'batchId':manifest['id'],'maximumPrimary':68,'maximumSemantic':68,'preparationConsumed':1,'primaryConsumed':ledger['attemptCount'],'primaryCompleted':sum(a['status']=='completed' for a in ledger['attempts']),'semanticConsumed':len(semantic_reservations),'semanticPassed':sum(r['status']=='passed' for r in semantic_receipts),'parentVerified':len(proofs),'latestVerified':proofs[-1]['slot'] if proofs else None,'primaryLedgerSha256':io.sha(io.read_regular(lp)),'stop':ledger.get('stop'),'primaryUsage':usage(primary_usage),'semanticUsage':usage(semantic_usage),'oldConditions01To05':'each_preparation1_primary0_stopped_preserved','oldCondition06':'preparation1_primary2_semantic1_permanent_stop_preserved','certifiesSkillGate':False,'certifiesRelease':False}
public=Path('/home/hide/BitzLabs/BitzSkills/.venv/skills-integration-worktree/evals/skills/results/2026-10-11-development-plan')
p=public/'r05-new07-progress.json';p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
p=public/'r05-new07-execution-contract.json';fixed=load(p)
assert fixed['sourceCommit']==source and fixed['primary']['maximum']==record['maximumPrimary'] and fixed['semantic']['maximum']==record['maximumSemantic']
fixed['status']=record['status'];fixed['primary']['consumed']=record['primaryConsumed'];fixed['semantic']['consumed']=record['semanticConsumed'];fixed['parentVerified']=record['parentVerified']
fixed['driverSha256']['r05-new07-update-progress.py']=io.sha(io.read_regular(Path(__file__).absolute()))
p.write_text(json.dumps(fixed,ensure_ascii=False,indent=2)+'\n')
p=public/'summary.json';v=json.loads(p.read_text());v['developmentProgress']['r05']=record['status'];v['developmentProgress']['r05New07']={k:record[k] for k in ['sourceCommit','status','preparationConsumed','primaryConsumed','semanticConsumed','semanticPassed','parentVerified','maximumPrimary','maximumSemantic','certifiesSkillGate']};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
plan=Path('/home/hide/BitzLabs/BitzSkills/.venv/skills-integration-worktree/docs/04.提案資料/31_スキル統合残件の開発計画と進捗.md');s=plan.read_text();lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| R05 |'):
  cells=line.split('|');cells[-2]=f" {'停止' if record['stop'] else '進行中'}（新07: 一次{record['primaryConsumed']}/68・独立{record['semanticConsumed']}/68・親原照合{record['parentVerified']}/68。全709件・準備SOL49通過） ";lines[i]='|'.join(cells);break
plan.write_text('\n'.join(lines)+'\n')
print(json.dumps({k:record[k] for k in ['status','primaryConsumed','primaryCompleted','semanticConsumed','semanticPassed','parentVerified','latestVerified','stop']},ensure_ascii=False))
