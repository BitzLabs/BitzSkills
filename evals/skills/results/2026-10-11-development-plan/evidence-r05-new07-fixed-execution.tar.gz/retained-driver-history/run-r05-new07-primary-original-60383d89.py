"""固定した新07の次枠1件だけ。実呼出しの前後に原条件を保存する。"""
from pathlib import Path
import os, sys, json, subprocess, time, hashlib, importlib.util
root = Path.cwd()
source = '915fae1290cb632cd53f6b7fcfb906d5c98b2e30'
sys.path.insert(0, str(root / 'evals/skills/routing'))
import production_ledger as original_io

def read_raw(path):
    return original_io.read_regular(Path(path).absolute())
assert len(sys.argv) == 2 and sys.argv[1].isdigit()
ordinal = int(sys.argv[1])
assert 1 <= ordinal <= 68
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
sha = lambda p: hashlib.sha256(read_raw(p)).hexdigest()
prep = root / '.venv/r05-matrix-prelaunch-sol-07'
receipt = json.loads(read_raw(prep / 'receipt.json'))
assert receipt['status'] == 'static_sdd_prelaunch_review_passed' and receipt['sourceCommit'] == source
assert receipt['actualInvocations'] == 1 and receipt['consumedReservations'] == 1 and (receipt['primaryModelTrajectories'] == 0)
assert receipt['runtimeUnchanged'] and receipt['predecessorsUnchanged'] and (not receipt['response']['findings'])
for name, h in receipt['artifactSha256'].items():
    assert sha(prep / name) == h, name
import production_canary_capture as capture
bound, _ = capture.prepare(source)
manifest = root / 'evals/skills/sdd/batches/plan-implement-matrix-20261012-07.json'
batch = json.loads(read_raw(manifest))
assert batch['maximumPrimaryCalls'] == 68 and 'preparationStop' not in batch
slot = batch['slots'][ordinal - 1]
lp = root / '.venv/sdd-batch-ledgers' / (batch['id'] + '.json')
if lp.exists():
    ledger = json.loads(read_raw(lp))
    assert ledger['attemptCount'] == ordinal - 1 and 'stop' not in ledger
else:
    assert ordinal == 1
integration = root.parents[1]
node = integration / '.venv/fixed-codex-0.160.1'
codex = node / 'bin/codex'
assert subprocess.check_output([str(codex), '--version'], env=dict(os.environ, PATH=str(node / 'bin') + ':/usr/bin:/bin'), text=True).strip() == 'codex-cli 0.160.1'
pythonpath = str(root / 'plugins/bitz-core/src') + ':' + str(root / 'plugins/bitz-core/.venv/lib/python3.12/site-packages') + ':/usr/lib/python3/dist-packages'
output = root / '.venv/sdd-plan-implement-matrix-20261012-07'
argv = ['/usr/bin/python3', '-B', 'evals/skills/sdd/evaluate.py', 'run', '--batch', str(manifest), '--variant', slot['variant'], '--repetition', str(slot['repetition']), '--model', 'gpt-6.1-sol', '--model-version', 'unversioned-alias-observed-2026-10-13', '--pythonpath', pythonpath, '--output', str(output), '--case', slot['caseId'], '--jobs', '1', '--timeout', '240']
base = root / '.venv/r05-new07-primary-process' / f'attempt-{ordinal:02d}'
base.mkdir(parents=True, exist_ok=False)
config = dict(argv=argv, sourceCommit=source, slot=slot, ordinal=ordinal, maximumPrimaryCalls=68, automaticRetries=0, preparationReceiptSha256=sha(prep / 'receipt.json'), manifestSha256=sha(manifest), runnerSha256=sha(Path(__file__)), providerCost=None)
(base / 'command.json').write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n')
env = dict(os.environ, PATH=str(node / 'bin') + ':/home/hide/.local/bin:/usr/bin:/bin', PYTHONPATH=pythonpath, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(root / '.venv/test-temp'))
started = time.monotonic()
code = None
error = None
with (base / 'stdout').open('xb') as stdout, (base / 'stderr').open('xb') as stderr:
    try:
        code = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=300).returncode
    except BaseException as exc:
        error = type(exc).__name__ + ': ' + str(exc)
post_errors = {}
def stored_hash(path):
    try:
        return sha(path)
    except Exception as exc:
        post_errors[str(path)] = type(exc).__name__ + ': ' + str(exc)
        return None
summary = dict(exitCode=code, error=error, seconds=time.monotonic()-started,
               sourceCommit=source, slot=slot, ordinal=ordinal,
               stdoutSha256=stored_hash(base/'stdout'), stderrSha256=stored_hash(base/'stderr'),
               cleanAfter=None, gateDecision='not-certified')
try:
    summary['cleanAfter'] = subprocess.check_output(['git','status','--porcelain'],cwd=root)==b''
    if lp.exists():
        ledger_state = json.loads(read_raw(lp))
        summary['ledgerSha256'] = stored_hash(lp)
        summary['attemptCount'] = ledger_state['attemptCount']
        summary['attempts'] = ledger_state['attempts']
except Exception as exc:
    post_errors['source-or-ledger'] = type(exc).__name__ + ': ' + str(exc)
target = output / slot['variant'] / f"repetition-{slot['repetition']}" / slot['caseId']
summary['artifacts'] = {}
for name in ('run.json','failure.json','trace.jsonl','host.jsonl','changes.json','decision.json',
             'control.json','stderr.log','prompt.txt','invocation.json'):
    path = target / name
    try:
        if path.exists() or path.is_symlink():
            summary['artifacts'][name] = stored_hash(path)
    except Exception as exc:
        post_errors[name] = type(exc).__name__ + ': ' + str(exc)
summary['postVerificationErrors'] = post_errors
if post_errors:
    summary['error'] = summary['error'] or 'original process/ledger/artifact verification failed'
(base / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False))
sys.exit(code if code is not None and not post_errors else 1)
