from pathlib import Path
import argparse,hashlib,json,os,re,sys,unittest
from unittest.mock import patch
R=Path.cwd();os.umask(0o077);sys.path.insert(0,str(R/'tests/skills'));sys.path.insert(0,str(R/'evals/skills/routing'))
import test_production_heldout_phases as fixture
p=fixture.p
sha=lambda b:hashlib.sha256(b).hexdigest()

class AdditionalTests(fixture.PhasePrimitiveTests):
 def preserve(self,label,root):
  base=OUTPUT/self._testMethodName/label;base.mkdir(mode=0o700,parents=True)
  for path in root.iterdir():
   if path.is_file() and not path.is_symlink():(base/path.name).write_bytes(path.read_bytes())
 def evidence(self,value):
  base=OUTPUT/self._testMethodName;base.mkdir(mode=0o700,parents=True,exist_ok=True)
  (base/'observation.json').write_bytes(p.io.encoded(value))
 def copied(self,name):
  root=self.f.root.parent/name;root.mkdir(mode=0o700)
  for path in self.f.root.iterdir():(root/path.name).write_bytes(path.read_bytes())
  return root
 def test_event_changed_after_its_read_is_rejected(self):
  self.preserve('before',self.f.root);original=p._read;fired=[]
  def change(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json' and not fired:
    row=p.inputs.parse(raw);row['measuredCorrect']=False;(root/name).write_bytes(p.io.encoded(row));fired.append(True)
   return raw
  error=None;snapshot=None
  try:
   with patch.object(p,'_read',side_effect=change):snapshot=self.snapshot()
  except ValueError:error='ValueError'
  self.preserve('after',self.f.root);current=self.snapshot()
  self.evidence(dict(rejected=error is not None,returnedHead=None if snapshot is None else snapshot.head,currentHead=current.head,returnedCorrect=None if snapshot is None else snapshot.counts()['correct'],currentCorrect=current.counts()['correct']))
  self.assertEqual(error,'ValueError','scanner accepted stale event bytes after same-file replacement')
 def test_contract_changed_after_initial_read_is_rejected(self):
  self.preserve('before',self.f.root);original=p._read;fired=[]
  def change(root,name,**kwargs):
   raw=original(root,name,**kwargs)
   if name=='event-0014.json' and not fired:
    (root/'contract.json').write_bytes(p.io.encoded(dict(p.inputs.parse(self.raw),sourceCommit='f'*40)));fired.append(True)
   return raw
  error=None;snapshot=None
  try:
   with patch.object(p,'_read',side_effect=change):snapshot=self.snapshot()
  except ValueError:error='ValueError'
  self.preserve('after',self.f.root)
  self.evidence(dict(rejected=error is not None,returnedContractSha256=None if snapshot is None else sha(snapshot.contract_raw),currentContractSha256=sha((self.f.root/'contract.json').read_bytes())))
  self.assertEqual(error,'ValueError','scanner accepted snapshot after its contract changed')
 def test_directory_aba_cannot_substitute_bytes_from_unlocked_root(self):
  alternate=self.copied('alternate');path=alternate/'event-0014.json';row=p.inputs.parse(path.read_bytes());row['measuredCorrect']=False;path.write_bytes(p.io.encoded(row))
  self.preserve('locked-original',self.f.root);self.preserve('alternate',alternate)
  original=p._read;fired=[];backup=self.f.root.parent/'temporarily-moved-locked-directory'
  def swap(root,name,**kwargs):
   if name=='event-0014.json' and not fired:
    root.rename(backup);alternate.rename(root)
    try:raw=original(root,name,**kwargs)
    finally:root.rename(alternate);backup.rename(root)
    fired.append(True);return raw
   return original(root,name,**kwargs)
  error=None;snapshot=None
  try:
   with patch.object(p,'_read',side_effect=swap):snapshot=self.snapshot()
  except ValueError:error='ValueError'
  actual=self.snapshot();self.preserve('locked-after',self.f.root)
  self.evidence(dict(rejected=error is not None,returnedHead=None if snapshot is None else snapshot.head,lockedRootHead=actual.head,returnedCorrect=None if snapshot is None else snapshot.counts()['correct'],lockedRootCorrect=actual.counts()['correct'],originalDirectoryRestored=True))
  self.assertEqual(error,'ValueError','scanner accepted a row read from an unlocked replacement directory')
 def test_mismatched_directory_fd_and_root_are_rejected(self):
  other=self.copied('other')
  with p.journal_read_lock(other) as directory:
   with self.assertRaises(ValueError):p.scan_journal(directory,self.f.root,self.raw,2)
 def test_readonly_lock_wrong_mode_is_rejected(self):
  (self.f.root/'lock').chmod(0o644)
  with self.assertRaises(ValueError):self.snapshot()
 def test_readonly_lock_hardlink_is_rejected(self):
  os.link(self.f.root/'lock',self.f.root.parent/'second-lock-link')
  with self.assertRaises(ValueError):self.snapshot()
 def test_symlinked_event_original_is_rejected(self):
  event=self.f.root/'event-0014.json';target=self.f.root.parent/'separate-event';target.write_bytes(event.read_bytes());event.unlink();event.symlink_to(target)
  with self.assertRaises((ValueError,OSError)):self.snapshot()
 def test_contract_larger_than_per_file_limit_is_rejected(self):
  large=self.raw+b' '*(65537-len(self.raw));(self.f.root/'contract.json').write_bytes(large)
  with self.assertRaises(ValueError):p.read_journal(self.f.root,large,2)
 def test_event_count_over_finite_bound_is_rejected(self):
  for n in range(15,p.MAX_EVENTS+2):(self.f.root/f'event-{n:04d}.json').write_bytes(b'{}')
  with self.assertRaises(ValueError):self.snapshot()
 def test_failure_cannot_claim_a_different_resource_proof(self):
  before=set(self.f.root.parent.iterdir());self.phase_fixture(4,slots=[(4,'primary_failed')]);root=next(iter(set(self.f.root.parent.iterdir())-before));event=root/'event-0003.json';v=p.inputs.parse(event.read_bytes());v['resourceProofSha256']='0'*64;event.write_bytes(p.io.encoded(v))
  with self.assertRaises(ValueError):p.read_journal(root,(root/'contract.json').read_bytes(),4)
 def test_captured_without_parent_terminal_cannot_be_carried(self):
  phase=self.phase_fixture(4,pending=[(4,name) for name in p.legacy.STAGES[:-1]])
  with self.assertRaises(ValueError):p.carry_forward([self.snapshot(),phase])
 def test_snapshot_rows_and_fields_are_immutable(self):
  snapshot=self.snapshot();before=snapshot.counts()
  with self.assertRaises((AttributeError,TypeError)):snapshot.head='0'*64
  with self.assertRaises(TypeError):snapshot.rows[-1]['measuredCorrect']=False
  copied=dict(snapshot.rows[-1]);copied['measuredCorrect']=False
  self.assertEqual(snapshot.counts(),before)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',required=True,type=Path);args=parser.parse_args();OUTPUT=args.output
 assert OUTPUT.is_absolute() and OUTPUT.parent==R/'.venv' and re.fullmatch(r'r04-phase-primitives-extra-[a-z0-9-]+',OUTPUT.name) and not OUTPUT.exists();OUTPUT.mkdir(mode=0o700)
 names=sorted(name for name in AdditionalTests.__dict__ if name.startswith('test_'))
 suite=unittest.TestSuite(AdditionalTests(name) for name in names)
 with (OUTPUT/'stderr.log').open('w') as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 value=dict(count=result.testsRun,failures=len(result.failures),errors=len(result.errors),exitCode=0 if result.wasSuccessful() else 1,testHelperSha256=sha(Path(__file__).read_bytes()),models=0,reservations=0,privateWrites=0,syntheticOnly=True)
 (OUTPUT/'result.json').write_bytes(p.io.encoded(value));print(json.dumps(value));raise SystemExit(value['exitCode'])
