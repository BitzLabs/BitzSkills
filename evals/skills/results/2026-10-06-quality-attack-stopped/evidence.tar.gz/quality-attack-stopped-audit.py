"""停止した2軌跡を再検査し、失敗と境界未確定を保存する。"""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-attack-01"
attempts = evaluate.load(output / "attempts.json")
conditions = evaluate.load(output / "conditions.json")
case = evaluate.load(HERE / "attack-cases.json")["cases"][0]
assert len(attempts) == 2
rows, common, threads = [], [], []
for attempt in attempts:
    directory = output / attempt["directory"]
    record, control = (evaluate.load(directory / name) for name in ("run.json", "control.json"))
    assert all(record["identity"][key] == value for key, value in conditions.items())
    errors, advice = evaluate.inspect_record(directory, case, record)
    assert errors == record["checks"]
    assert advice == evaluate.load(directory / "advice.json")
    common.append({**{k: control[k] for k in ("baseCommit", "subjectCommit", "fixtureFiles", "diff", "allowTests")},
        "readableFiles": {n: h for n, h in control["readableFiles"].items() if not n.startswith("resources/bitz-quality/skills/")}})
    calls = evaluate.jsonl(directory / "host.jsonl")
    tests = [c for c in calls if c["tool"] == "run_fixture_test" and c["accepted"]]
    assert tests and all(c["result"]["exitCode"] == 0 and "Ran 1 test" in c["result"]["stderr"] for c in tests)
    assert not any(not c["accepted"] for c in calls)
    trace = evaluate.jsonl(directory / "trace.jsonl")
    thread = [e["thread_id"] for e in trace if e.get("type") == "thread.started"]
    assert len(thread) == 1
    threads.extend(thread)
    rows.append({"runId": record["identity"]["runId"], "variant": record["identity"]["variant"],
        "sourceCommit": record["identity"]["sourceCommit"], "subjectCommit": control["subjectCommit"],
        "checks": errors, "frozenCheckerPassed": not any(errors.values()), "riskBand": advice["riskBand"],
        "decision": advice["decision"], "independence": advice["independence"],
        "humanDecisionPending": advice["humanDecisionPending"], "missingEvidenceIds": advice["missingEvidenceIds"],
        "findingCount": len(advice["findings"]), "testCalls": len(tests), "hostCalls": len(calls),
        "threadId": thread[0], "wallMs": record["wallMs"], "usage": record["usage"],
        "runSha256": evaluate.sha((directory / "run.json").read_bytes()),
        "receiptPresent": (directory / "independent-receipt.json").exists()})
assert common[0] == common[1] and len(set(threads)) == 2
old = evaluate.load(ROOT / ".venv/quality-attack-preparation-01/parent-audit.json")["oldEvidence"]
assert all(evaluate.sha((ROOT / p).read_bytes()) == h for p, h in old.items())
print(json.dumps({"schemaVersion": "1.0", "status": "stopped", "originalComparisonStatus": "failed",
    "sourceCommit": conditions["sourceCommit"], "model": conditions["model"],
    "maximumNewPrimaryTrajectories": 4, "primaryAttempts": 2, "unusedPrimaryTrajectories": 2,
    "unusedBudgetReusable": False, "independenceInterpretation": "unknown",
    "sameSourceAndConditions": True, "identicalCommonInputsAndPermissions": True,
    "uniqueNativeThreads": 2, "oldEvidenceUnchanged": len(old), "automaticRetry": False,
    "certifiesSkillGate": False, "rows": rows}, ensure_ascii=False, indent=2))
