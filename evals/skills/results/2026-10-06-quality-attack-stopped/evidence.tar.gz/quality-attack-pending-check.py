"""未検分の実軌跡から新たなCodexを起動できないことを検査する。"""
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-attack-01"
approval = HERE / "attack-approval.json"
ledger = ROOT / ".venv" / ("quality-pilot-" + evaluate.sha(approval.read_bytes()) + "-authorization.json")
paths = [ledger, output / "attempts.json", output / "independent-budget.json"]
before = {str(p): p.read_bytes() for p in paths}
backend_calls = []
original_run = evaluate.subprocess.run


def observed(argv, **kwargs):
    if argv[0] == "codex":
        backend_calls.append(argv)
        raise AssertionError("unreviewed; Codex must not execute")
    return original_run(argv, **kwargs)


reason = None
with patch("evaluate.subprocess.run", side_effect=observed):
    try:
        evaluate.measure(SimpleNamespace(output=output, protocol=HERE / "attack-protocol.json", approval=approval, timeout=600))
    except ValueError as error:
        reason = str(error)
assert reason == "previous trajectory needs independent review; no new call", reason
assert not backend_calls
assert before == {str(p): p.read_bytes() for p in paths}
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "primaryAttempts": len(evaluate.load(output / "attempts.json")),
    "additionalCodexCalls": len(backend_calls), "ledgerAndAttemptsUnchanged": True,
    "reason": reason, "automaticRetry": False}, ensure_ascii=False, indent=2))
