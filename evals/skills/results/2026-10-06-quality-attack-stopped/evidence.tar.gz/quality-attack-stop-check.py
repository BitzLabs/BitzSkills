"""一次失敗後の実再開拒否と旧台帳の保持を検査する。"""
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "evals/skills/quality"
sys.path.insert(0, str(HERE))
import evaluate

output = ROOT / ".venv/quality-attack-01"
approval = HERE / "attack-approval.json"
ledger = ROOT / ".venv" / ("quality-pilot-" + evaluate.sha(approval.read_bytes()) + "-authorization.json")
paths = [ledger, output / "attempts.json", output / "independent-budget.json", output / "stop.json"]
before = {str(p): p.read_bytes() for p in paths}
old = evaluate.load(ROOT / ".venv/quality-attack-preparation-01/parent-audit.json")["oldEvidence"]
assert all(evaluate.sha((ROOT / p).read_bytes()) == h for p, h in old.items())
assert evaluate.load(ledger)["attemptCount"] == len(evaluate.load(output / "attempts.json")) == 2
backend_calls = []
original_run = evaluate.subprocess.run


def observed(argv, **kwargs):
    if argv[0] == "codex":
        backend_calls.append(argv)
        raise AssertionError("failed comparison; Codex must not execute")
    return original_run(argv, **kwargs)


reason = None
with patch("evaluate.subprocess.run", side_effect=observed):
    try:
        evaluate.measure(SimpleNamespace(output=output, protocol=HERE / "attack-protocol.json", approval=approval, timeout=600))
    except ValueError as error:
        reason = str(error)
assert reason in {"previous trajectory needs independent review; no new call",
                  "previous independent review failed or evidence changed; no new call",
                  "previous actual evidence failed reinspection; no new call"}, reason
assert not backend_calls
assert before == {str(p): p.read_bytes() for p in paths}
assert all(evaluate.sha((ROOT / p).read_bytes()) == h for p, h in old.items())
print(json.dumps({"schemaVersion": "1.0", "status": "passed", "primaryAttempts": 2,
    "unusedPrimaryTrajectories": 2, "unusedBudgetReusable": False,
    "additionalCodexCalls": len(backend_calls), "ledgerAndAttemptsUnchanged": True,
    "oldEvidenceUnchanged": len(old), "reason": reason, "automaticRetry": False}, ensure_ascii=False, indent=2))
