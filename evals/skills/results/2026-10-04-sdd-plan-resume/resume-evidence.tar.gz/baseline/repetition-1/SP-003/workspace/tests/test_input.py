import importlib.util
from pathlib import Path
import unittest
spec = importlib.util.spec_from_file_location("input_contract", Path(__file__).resolve().parents[1] / "src/input.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
class InputContractTest(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(1, len(module.validate("")))
    def test_nonempty(self):
        self.assertEqual([], module.validate("abc"))
if __name__ == "__main__":
    unittest.main()
