---
id: TASK-001
title: 既存契約内で入力関数を保守する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 既存契約内で入力関数を保守する

## Objective

所有ワークスペースrootの承認済みREQ-001:AC-01に対応する入力関数を、指定境界内で保守する。要求の意味は変更せず、新規REQ／TECHは作成しない。今回の工程はTASKの保存と検査までとし、実装は後続の依頼を待つ。

## Plan

簡易フロー、リスクQ1。局所的で可逆な既存契約内の変更であり、公開契約や永続データを変更する計画はない。先行TASKの前提はない。
後続ではTASK-001の実装用contextを完全解決・通過状態で取得し、書込み直前にdigestを照合する。実装前checkを経て、changes内で修正し、実装後check・verify・最終差分の人手レビューへ進む。

## Evidence and Verification Plan

既存src/input.pyのvalidateは常に空リストを返している。既存tests/test_input.pyの空文字テストは戻り値の件数が1であることをassertし、REQ-001:AC-01の件数条件を検査する。非空文字abcのテストは空リストとの一致をassertするが、この事例を新たな要求へ拡張しない。
空文字テストには戻り値の型、要素の型やエラー内容のassertはなく、その証拠として扱わない。REQのVerificationにはテスト未実装との記載があるが、実ファイルは存在する。既存テストは未実行であり、要件の実証は未完了である。
後続のverifyは登録済みdefaultコマンド /usr/bin/python3 -I -B {tests}（cwd: .）を用いる。起動前にテスト本文と実行制約を再確認する。srcは副作用のないvalidate(value)の比較・分岐と文字列リストのreturnに限定し、テストも許可された固定assertの制約を守る。

## Completion Criteria

REQ-001の意味と指定境界を維持し、実装前後のCore検査、登録テストの実検証結果、最終差分の人手レビューを記録する。不足証拠や診断があれば対応する工程へ戻る。人手レビュー後にのみdoneへの更新と最終checkを行う。TASKの保存やcheck通過だけでは実装の完了・承認・出荷可能を主張しない。
