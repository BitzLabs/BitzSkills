---
id: TASK-001
title: 空入力の拒否と回帰テストを実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否と回帰テストを実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で実装と回帰テストを行う。起点REQがdraftの間は実装へ着手しない。

簡易フロー、リスク帯Q1を提案する。局所的で可逆な入力処理の変更であり、公開APIの拡張、永続化、外部操作は予定しない。要求の承認時にこの分類も確認する。

## Completion Criteria

要求承認後、実装用contextの完全解決・status・digestを確認し、実装前check、実装、実装後check、verify、最終差分の人手レビューを経る。必要な証拠を揃えた後に完了状態を判断する。本草案の保存やcheck通過は実装の許可ではない。

既存の tests/test_input.py は空入力の件数と非空入力の戻り値をassertするが、未実行である。空入力時の型と内容については検査証拠がない。登録テストと公開設定の /usr/bin/python3 -I -B による固定テストの安全条件を後続で確認する。srcには副作用のないvalidate(value)の比較・分岐と文字列リストのreturnだけを使用する。

境界はsrc/input.pyとtests/test_input.pyのみとする。境界検査が非成功なら実結果を報告し、利用者・要求担当者へ相談して停止する。境界拡張、REQ削除、比較元変更で検査を通さない。
