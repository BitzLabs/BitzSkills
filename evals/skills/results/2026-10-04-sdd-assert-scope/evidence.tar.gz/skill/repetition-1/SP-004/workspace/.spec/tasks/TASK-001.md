---
id: TASK-001
title: 既存契約内で入力関数を保守する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 既存契約内で入力関数を保守する

## Objective

rootワークスペースの承認済みREQ-001:AC-01を起点に、既存契約内で入力関数を保守する。要求の意味を変更せず、新規REQを作らない。変更境界はchangesの2ファイルに限定する。

## Plan

簡易フロー、Q1。局所的で可逆な既存契約内の変更であり、公開契約や永続データの変更は計画しない。本工程はTASKの保存と検査までとし、実装は行わない。

後続ではTASK-001の実装用contextを取得して完全解決・status・digestを確認し、実装前checkを行う。書込み直前にdigestを再照合し、境界内で実装と必要な回帰テストの保守を行う。

## Evidence and Verification

既存tests/test_input.pyのtest_emptyはvalidate("")の戻り値の件数が1であることをassertする。戻り値の型、要素の型・内容は検査しない。test_nonemptyはvalidate("abc")が空リストであることをassertし、既存互換性の回帰確認として扱う。テストは存在するが、本工程では未実行であり要件実証は未完了である。REQのVerificationにはテスト未実装との記載が残っており、現物との差異を後続レビューへ渡す。

後続の登録コマンドはdefault（/usr/bin/python3 -I -B {tests}、cwd: .）。実行前に固定テストと副作用のない入力関数という許可条件を確認する。型・要素の内容に関する証拠は不足しており、未合意の契約を追加しない。

## Completion Criteria

後続の実装前後のCore check、登録テストによるverify、最終差分と結果の人手レビューを経て完了する。未実行の結果を成功と扱わず、人手レビュー後にのみdoneへの変更と最終checkを行う。本工程のcheck通過は実装・要件実証・人間の承認を代替しない。
