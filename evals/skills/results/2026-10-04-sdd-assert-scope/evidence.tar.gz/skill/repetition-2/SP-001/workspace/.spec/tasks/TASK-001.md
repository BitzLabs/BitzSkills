---
id: TASK-001
title: 空入力の拒否と回帰テストを実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否と回帰テストを実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で入力検証と回帰テストを実装する。起点REQがdraftの間は実装へ着手しない。

## Plan

簡易フロー・Q1の提案とする。承認後、実装用contextの完全解決とdigestを確認し、実装前checkを実行する。src/input.pyは副作用のないvalidate(value)の比較・分岐と文字列リストのreturnに限定する。既存assertが検査する範囲を維持し、入力エラーであることの検査不足をtests/test_input.py内で補う計画とする。

## Completion Criteria

実装の前後のCore検査、設定のPython -I -Bによる固定テストのverify、最終差分の人手レビューを経て完了する。現時点でテストは未実行、要求は未承認であり、実装開始可能とは扱わない。

境界はsrc/input.pyとtests/test_input.pyだけとし、検査通過のために拡張しない。境界検査が非成功なら実結果を報告し、人間の利用者・要求レビュー担当へ相談して停止する。REQ削除、比較元変更、コミット、PUSH、外部操作、承認の生成は行わない。
