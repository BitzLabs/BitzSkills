import hashlib
import io
import json
import pathlib
import subprocess
import tarfile

review = pathlib.Path(__file__).resolve().parent
repo = review.parents[2]
out = repo / "evals/skills/results/2026-10-06-production-routing-preparation"
record = json.loads((review / "review.json").read_text())
assert record["status"] == "passed" and not record["findings"]
sha = lambda b: hashlib.sha256(b).hexdigest()
for name, expected in record["logHashes"].items():
    assert sha((review / name).read_bytes()) == expected
entries, fixed = {}, []
for path in review.iterdir():
    if path.is_file():
        entries["review/" + path.name] = path.read_bytes()
scope = json.loads(entries["review/scope.json"])
entries["review/budget-final.json"] = json.dumps(
    {**scope, "status": "completed", "consumedIndependentCalls": 1,
     "remainingIndependentCalls": 0}, ensure_ascii=False, indent=2).encode()
for source in record["sourceFiles"]:
    content = (repo / source["path"]).read_bytes()
    assert sha(content) == source["sha256"]
    assert content == subprocess.check_output(
        ["git", "show", record["sourceCommit"] + ":" + source["path"]], cwd=repo)
    name = "source/" + source["path"]
    entries[name] = content
    fixed.append({"ref": record["sourceCommit"], "path": source["path"], "archivePath": name})
for snapshot in ["snapshot", "independent-snapshot", "parent-recheck-snapshot"]:
    path = review.parent / snapshot / "manifest.json"
    assert sha(path.read_bytes()) == record["directChecks"]["snapshot"]["manifestSha256"]
    entries["snapshots/" + snapshot + "/manifest.json"] = path.read_bytes()
manifest = json.loads(entries["snapshots/snapshot/manifest.json"])
for name, expected in manifest["resources"].items():
    content = (review.parent / "snapshot" / name).read_bytes()
    assert sha(content) == expected
    source = "plugins/" + name.removeprefix("resources/")
    assert content == subprocess.check_output(
        ["git", "show", record["sourceCommit"] + ":" + source], cwd=repo)
    target = "source/" + source
    entries[target] = content
    fixed.append({"ref": record["sourceCommit"], "path": source, "archivePath": target})
out.mkdir()
with tarfile.open(out / "evidence.tar.gz", "w:gz") as archive:
    for name, content in sorted(entries.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(content), 0
        archive.addfile(info, io.BytesIO(content))
saved = {"schemaVersion": "1.0", "archiveSha256": sha((out / "evidence.tar.gz").read_bytes()),
         "files": {name: {"bytes": len(content), "sha256": sha(content)}
                   for name, content in sorted(entries.items())}, "fixedSources": fixed}
(out / "manifest.json").write_text(json.dumps(saved, indent=2) + "\n")
print(json.dumps({"files": len(entries), "fixedSources": len(fixed),
                  "bytes": sum(map(len, entries.values())), "archiveSha256": saved["archiveSha256"]}))
