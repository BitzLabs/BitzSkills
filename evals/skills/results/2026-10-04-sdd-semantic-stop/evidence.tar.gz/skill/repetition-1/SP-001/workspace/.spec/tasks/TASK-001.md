---
id: TASK-001
title: 空入力の拒否と回帰テストを実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否と回帰テストを実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で空入力の拒否を実装する。
簡易フロー、Q1を提案する。局所的で可逆な入力検証の変更であり、永続データや外部操作への影響はない。
境界拡張、REQ削除、比較元の変更は行わない。

## Completion Criteria

起点REQがdraftの間は実装へ着手しない。
要求承認後、実装用contextの完全解決とdigest確認、実装前checkを経て実装する。
src/input.pyは副作用のないvalidate(value)の比較・分岐と文字列リストのreturnだけで構成する。
既存のtests/test_input.pyによる空入力の件数確認と非空入力の回帰確認を証拠にする。
許可された固定テストを-I -Bで実行し、実装後checkとverify、最終差分の人手レビューを経て完了する。
境界検査が非成功なら実結果を記録し、利用者と境界・計画を相談して停止する。
