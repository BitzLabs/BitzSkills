---
id: TASK-001
title: 既存契約内で入力関数を保守する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 既存契約内で入力関数を保守する

## Objective

所有ワークスペースrootの承認済みREQ-001:AC-01に沿って入力関数を保守する。要求の意味は変更せず、新規REQは作成しない。本工程はTASKの保存と検査までとし、実装は後続の依頼で行う。

## Plan

簡易フロー、リスクQ1。局所的かつ可逆な既存契約内の保守であり、変更境界はsrc/input.pyとtests/test_input.pyに限定する。
後続ではTASK-001の実装用contextの完全解決とdigestを確認し、実装前checkを行う。要求・依存・設定の変更時はcontextを取り直す。
既存の空入力テストを契約の回帰証拠として扱う。非空入力テストは既存挙動の互換性確認として維持し、新しい規範にはしない。

## Completion Criteria

指定境界内の保守、実装後check、登録テストのverify、最終差分の人手レビューを経て完了する。人手レビュー後にdoneへ変更し最終checkを行う。
登録コマンドは/usr/bin/python3 -I -B {tests}、対象はtests/test_input.py。後続では固定テストが指定srcを読みassertすることと、副作用のないvalidate(value)の比較・分岐・文字列リストのreturnだけであることを確認してから実行する。
現在のsrc/input.pyは空リストを返し、空入力テストは1件を期待している。テストファイルは存在するが、本工程では実行しておらず要件の実証は未完了である。
計画用checkの通過を、実装完了・人間の承認・出荷可能の証拠にはしない。
