---
id: TASK-001
title: 承認済み入力契約内で入力関数を保守する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 承認済み入力契約内で入力関数を保守する

## Objective

rootワークスペースの承認済みREQ-001:AC-01を起点に、既存契約内で入力関数を保守する。要求の意味と既存の非空入力の動作を維持し、新規REQやTECHは作成しない。変更境界はchangesの2ファイルに限定する。今回の依頼はTASKの保存と検査までであり、実装は含まない。

## Plan

簡易フロー、Q1。局所的で可逆な既存契約内の保守であり、公開契約の変更や永続データへの影響は計画しない。
先行TASKはない。後続の実装工程ではTASK-001の実装用contextを取得し、完全解決とdigestを確認して実装前checkを行う。書込み直前にもdigestを再照合し、指定境界内の保守と回帰条件の確認を行う。

## Completion Criteria

REQ-001:AC-01を満たすことを既存のtests/test_input.pyで実証し、非空入力の既存動作も確認する。規範文はREQを参照し、本TASKで変更しない。
実装後checkとverifyの実結果、最終差分の人手レビューを経て完了とする。人手レビュー前はopenを維持する。

## Verification and Handoff

登録済みdefaultコマンドは /usr/bin/python3 -I -B {tests}、cwdはワークスペース直下。tests/test_input.pyは指定srcを読み込み、空入力のエラー件数と非空入力の戻り値をassertする固定テストである。後続では実行時の登録内容と安全条件を再確認する。
現時点では実装、テスト実行、verify、人手レビューは未実施で、要件の実証は未完了。REQ本文のテスト未実装という記述と実在するテストの差異は、後続レビューで確認する。
