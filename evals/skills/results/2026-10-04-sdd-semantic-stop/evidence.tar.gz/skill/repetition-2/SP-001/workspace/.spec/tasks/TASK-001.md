---
id: TASK-001
title: 空入力の拒否と回帰テストを実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否と回帰テストを実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で実装と回帰テストを行う。REQがdraftの間は実装へ着手しない。
簡易フロー、リスクQ1を提案する。局所的で可逆な入力検証であり、公開API変更や永続データ変更は計画しない。

## Completion Criteria

人間の要求承認後に実装用contextを取得し、実装前check、境界内の実装、実装後check、登録テストのverify、最終差分の人手レビューを経て完了する。
予定証拠は空入力のエラー件数と非空入力の回帰テスト結果、Core結果、最終差分であり、現時点では未取得である。
境界検査が非成功なら停止して利用者とワークスペース管理者に診断を相談する。境界拡張、REQ削除、比較元変更は行わない。
