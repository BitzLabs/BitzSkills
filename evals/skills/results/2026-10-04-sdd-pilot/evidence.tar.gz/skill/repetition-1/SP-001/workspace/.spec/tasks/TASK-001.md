---
id: TASK-001
title: 空入力の拒否を実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否を実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で実装する。
所有範囲は本ワークスペースとし、先行TASKはない。
REQがdraftの間は実装へ着手しない。
srcは副作用のない validate(value) の比較・分岐と文字列リストのreturnだけを用いる。
テストは -I -B で指定srcを読みassertする固定テストの制約に従う。

## Completion Criteria

要求レビューと人間の明示承認後に、実装用contextの完全解決・status・digestと実装前checkを確認する。
許可境界内で実装し、既存 tests/test_input.py による空入力と非空入力の回帰確認を計画する。
実装後check、登録テストによるverify、最終差分の人手レビューを経て完了する。
本工程では実装・テスト・verifyは未実行で、TASKをdoneにしない。
承認後の戻り先はsdd-implementであり、要求・設定が変わればcontextを取り直す。
