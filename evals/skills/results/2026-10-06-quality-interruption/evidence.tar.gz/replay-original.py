"""現在の回帰試験を原コミットの評価器へ接続する。Codexは試験側のSpyのみ。"""
from pathlib import Path
import subprocess
import sys
import types
import unittest

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "evals/skills/quality"
REF = "e515544660dcf115a5d8e523ec5228fa1705f780"
sys.path.insert(0, str(HERE))
source = subprocess.run(["git", "show", REF + ":evals/skills/quality/evaluate.py"],
                        cwd=ROOT, capture_output=True, check=True).stdout
module = types.ModuleType("evaluate")
module.__file__ = str(HERE / "evaluate.py")
sys.modules["evaluate"] = module
exec(compile(source, module.__file__, "exec"), module.__dict__)
suite = unittest.defaultTestLoader.discover(str(ROOT / "tests/skills"), pattern="test_quality_interruption.py")
result = unittest.TextTestRunner().run(suite)
raise SystemExit(not result.wasSuccessful())
