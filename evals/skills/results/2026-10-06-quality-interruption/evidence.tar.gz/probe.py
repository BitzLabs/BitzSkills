import ast, base64, hashlib, json, time, subprocess, sys, fcntl, errno
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
from unittest.mock import patch
BASE=Path(__file__).resolve().parent
src=(BASE/'original-evaluate.py').read_text()
tree=ast.parse(src)
functions=ast.Module(body=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in {'load','write','save_native_outputs','preserve_invocation_failure','measure'}],type_ignores=[])
results=[]
for mode in ['timeout','spawn-oserror','nonzero','save-error','post-oserror','nonutf8','keyboardinterrupt','success']:
 root=BASE/mode; root.mkdir(exist_ok=True); here=root/'evals/skills/quality'; here.mkdir(parents=True,exist_ok=True)
 protocol={'model':'gpt-6.1-sol','evaluationSetVersion':'x','pluginVersion':'x','maximumNewTrajectories':4,'variants':['skill','baseline'],'repetitions':2,'cases':[{'caseId':'QR-X'}]}
 (here/'protocol.json').write_text(json.dumps(protocol))
 approval={'approvalStatus':'approved','protocolSha256':hashlib.sha256((here/'protocol.json').read_bytes()).hexdigest(),'model':'gpt-6.1-sol','evaluationSetVersion':'x','pluginVersion':'x','maximumNewTrajectories':4}
 (here/'approval.json').write_text(json.dumps(approval))
 (here.parent/'sol-authorization.json').write_text(json.dumps({'approvalStatus':'approved','approvedBy':'user','models':['gpt-6.1-sol'],'scope':'BitzSkillsの開発に必要なsol評価、独立検分と是正後の新測定'}))
 package=root/'plugins/bitz-quality';package.mkdir(parents=True,exist_ok=True);(package/'plugin.json').write_text('{"version":"x"}')
 out=root/'.venv/output';calls=[]
 @contextmanager
 def lock(*a):
  yield root/'ledger.json',{'attemptCount':0}
 def setup(directory,case,variant,run):
  workspace=directory/case['caseId'];workspace.mkdir();return workspace,{'subjectCommit':'b'*40,'readableFiles':{}}
 def run(command,**kw):
  calls.append(command)
  if command==['codex','--version']:return SimpleNamespace(returncode=0,stdout='codex mock')
  if mode=='timeout':raise subprocess.TimeoutExpired(command,1,output=b'\xffpartial',stderr=b'stderr')
  if mode=='spawn-oserror':raise OSError(errno.ENOENT,'synthetic launch')
  if mode=='nonutf8':raise UnicodeDecodeError('utf-8',b'\xffpartial',0,1,'invalid start byte')
  if mode=='keyboardinterrupt':raise KeyboardInterrupt()
  directory=out/'quality-pilot-skill-r1-QR-X';(directory/'response.json').write_text('{}')
  return SimpleNamespace(returncode=2 if mode=='nonzero' else 0,stdout='original trace\r\n',stderr='original stderr\r\n')
 def inspect(*a):
  if mode=='post-oserror':raise OSError(errno.EIO,'synthetic later read')
  return {'mechanical':[],'safety':[],'evidence':[]},None
 ns=dict(Path=Path,json=json,base64=base64,time=time,sys=sys,fcntl=fcntl,subprocess=SimpleNamespace(run=run,TimeoutExpired=subprocess.TimeoutExpired,SubprocessError=subprocess.SubprocessError),ROOT=root,HERE=here,PACKAGE=package,sha=lambda b:hashlib.sha256(b).hexdigest(),preflight=SimpleNamespace(files=lambda p:{},environment=lambda:{'PYTHONPATH':'mock'},git=lambda args,*rest:b'' if args[0]=='status' else b'a'*40),authorization_lock=lock,setup=setup,model_configs=lambda *a:{},prompt=lambda *a:'instruction',inspect_record=inspect,jsonl=lambda *a:[])
 exec(compile(functions,'original-evaluate.py','exec'),ns)
 original=Path.write_bytes
 def write_bytes(path,data):
  if mode=='save-error' and path.name=='trace.jsonl':raise OSError(errno.ENOSPC,'synthetic full')
  return original(path,data)
 try:
  with patch.object(Path,'write_bytes',autospec=True,side_effect=write_bytes):
   value=ns['measure'](SimpleNamespace(output=out,timeout=1,approval=here/'approval.json',protocol=here/'protocol.json'))
  outcome='return '+str(value)
 except BaseException as e:outcome=type(e).__name__
 directory=out/'quality-pilot-skill-r1-QR-X'
 record=json.loads((directory/'interruption.json').read_text()) if (directory/'interruption.json').exists() else None
 results.append({'mode':mode,'outcome':outcome,'invocationCount':sum(c!=['codex','--version'] for c in calls),'traceBase64':base64.b64encode((directory/'trace.jsonl').read_bytes()).decode() if (directory/'trace.jsonl').exists() else None,'stderrBase64':base64.b64encode((directory/'stderr.log').read_bytes()).decode() if (directory/'stderr.log').exists() else None,'interruption':record,'runExists':(directory/'run.json').exists(),'attemptCount':len(json.loads((out/'attempts.json').read_text()))})
(BASE/'probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for r in results: print(json.dumps({k:r[k] for k in ['mode','outcome','invocationCount','traceBase64','stderrBase64','runExists','attemptCount']}|{'interruptionError':r['interruption']['errorType'] if r['interruption'] else None},ensure_ascii=False))
