---
id: TASK-001
title: 空入力の拒否と回帰テストを実装する
status: open
relations:
  addresses:
    - REQ-001:AC-01
changes:
  - src/input.py
  - tests/test_input.py
---

# TASK-001 空入力の拒否と回帰テストを実装する

## Objective

REQ-001:AC-01の意味が人間に承認された後、指定境界内で実装と回帰テストを行う。REQがdraftの間は実装へ着手しない。

## Plan

簡易フローを予定する。局所的で可逆な入力処理としてリスク帯はQ1を提案し、要求レビューで確認する。
承認後に実装用contextを完全解決し、実装前checkを行う。src/input.pyのvalidate(value)では副作用のない比較・分岐と文字列リストのreturnだけを用いる。
境界拡張、REQ削除、比較元変更は行わない。

## Completion Criteria

実装前後のCore検査、登録済みテストのverify、最終差分の人手レビューを経て完了する。
テスト予定はtests/test_input.pyでの空入力の件数と非空入力の回帰確認である。登録コマンドは/usr/bin/python3 -I -B {tests}で、計画工程では実行しない。
要求承認、実装用context、実装前検査、実装・検証の証拠は未取得である。境界検査が非成功なら実結果を示し、利用者と境界・仕様管理担当者への相談に戻る。
