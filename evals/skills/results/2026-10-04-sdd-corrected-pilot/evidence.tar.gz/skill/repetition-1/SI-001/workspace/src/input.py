def validate(value):
    if value == "":
        return ["入力が空です"]
    return []
