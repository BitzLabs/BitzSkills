import importlib.util, subprocess, sys, types, unittest
from pathlib import Path
ROOT=Path('/home/hide/BitzLabs/BitzSkills/.venv/skills-integration-worktree')
ref='3d98bf728498d6fa511cf53a454a587fc75be00a'
spec=importlib.util.spec_from_file_location('novelty_fixed_tests', ROOT/'tests/skills/test_held_out_novelty.py')
tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
path=ROOT/'evals/skills/routing/audit_held_out.py'
source=subprocess.run(['git','show',ref+':evals/skills/routing/audit_held_out.py'],cwd=ROOT,capture_output=True,check=True).stdout
old=types.ModuleType('old_novelty_audit');old.__file__=str(path)
exec(compile(source,str(path),'exec'),old.__dict__)
tests.audit=old
result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
raise SystemExit(0 if result.wasSuccessful() else 1)
